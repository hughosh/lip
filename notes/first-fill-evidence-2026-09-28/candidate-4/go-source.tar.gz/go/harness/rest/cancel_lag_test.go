package rest

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"testing"

	"lip/harness/risk"
)

// lip-kaf. The 2026-09-28 first stage raised six SEV1 SWEEP_INCOMPLETE records,
// and every one of them came 0.27-1.2 s AFTER the exchange's own terminal time
// for the order it named. Three consecutive YES sweeps, finishing 0.28, 0.68 and
// 1.08 s after that order's `last_update_time`, still found it in a complete
// `status=resting` read. The DELETE had worked; the resting LIST had not caught
// up. Each sweep's two rounds take about 0.4 s, so a list that lags a cancel by
// longer than that fails every sweep.
//
// These tests pin both halves. An order the exchange reports terminal, as its
// own record, is not "live and fillable" and must not page SEV1 (H-FAIL-3:
// confirmed gone "by response or by sweep"). And nothing short of that report
// -- absence from a named read, a 404, an error, a record for another order, a
// resting record -- may retire a requested order the list still shows.

const lagTicker = "KXLAG-26OCT08-T110"

// lagOrder is the exchange's own record for one order.
type lagOrder struct {
	id, coid, side string
	yes4, no4      string
	remaining      string // while it rested
	status         string
	created        string
	updated        string
	// staleReads is how many further `status=resting` list reads still show
	// this order after the exchange cancelled it.
	staleReads int
}

func (o *lagOrder) record(ticker, status, remaining, updated string) map[string]any {
	book := string(Bid)
	if o.side == "no" {
		book = string(Ask)
	}
	return map[string]any{
		"order_id":           o.id,
		"client_order_id":    o.coid,
		"ticker":             ticker,
		"side":               "yes",
		"book_side":          book,
		"outcome_side":       o.side,
		"yes_price_dollars":  o.yes4,
		"no_price_dollars":   o.no4,
		"remaining_count_fp": remaining,
		"status":             status,
		"created_time":       o.created,
		"last_update_time":   updated,
	}
}

// lagExchange is a stateful exchange whose resting-orders LIST lags its order
// records. A cancelled order keeps appearing in `status=resting` reads for
// `lag` further reads; a named-order GET answers from the record itself.
type lagExchange struct {
	t      *testing.T
	orders []*lagOrder
	// lag is the staleReads a successful cancel installs.
	lag int
	// staleStatus renders a stale listing with the record's CURRENT status (the
	// filter lagged, the record did not). Otherwise it is rendered exactly as it
	// rested.
	staleStatus bool
	// ignoreDeletes answers every DELETE 200 and cancels nothing: the order
	// really does persist.
	ignoreDeletes bool
	// named overrides the named-order GET answer.
	named func(id string) (Response, error)

	deletes []string
	gets    []string
	lists   int
}

const lagCancelledAt = "2026-09-28T20:19:22.315385Z"

func newLagExchange(t *testing.T, lag int) *lagExchange {
	return &lagExchange{t: t, lag: lag, orders: []*lagOrder{
		{id: "oY", coid: "lipH-run1-000-yes-00000001", side: "yes",
			yes4: "0.2300", no4: "0.7700", remaining: "12.00",
			status: StatusResting, created: "2026-09-28T19:33:06.843172Z",
			updated: "2026-09-28T19:33:06.843172Z"},
		{id: "oN", coid: "lipH-run1-000-no-00000002", side: "no",
			yes4: "0.6100", no4: "0.3900", remaining: "12.00",
			status: StatusResting, created: "2026-09-28T19:33:06.942929Z",
			updated: "2026-09-28T19:33:06.942929Z"},
	}}
}

func (x *lagExchange) find(id string) *lagOrder {
	for _, o := range x.orders {
		if o.id == id {
			return o
		}
	}
	return nil
}

// fresh is the named-order GET body for o, from the record itself.
func (x *lagExchange) fresh(o *lagOrder) Response {
	rem := o.remaining
	if o.status != StatusResting {
		rem = "0.00"
	}
	body, err := json.Marshal(map[string]any{
		"order": o.record(lagTicker, o.status, rem, o.updated)})
	if err != nil {
		panic(err)
	}
	return Response{Status: 200, Body: body}
}

func (x *lagExchange) Do(_ context.Context, req Request) (Response, error) {
	switch {
	case req.Method == "DELETE" &&
		strings.HasPrefix(req.Path, "/portfolio/events/orders/"):
		id := strings.TrimPrefix(req.Path, "/portfolio/events/orders/")
		if got := req.Query.Get("market_ticker"); got != lagTicker {
			x.t.Errorf("DELETE %s routed by market_ticker %q", id, got)
		}
		x.deletes = append(x.deletes, id)
		o := x.find(id)
		if o == nil || o.status != StatusResting {
			return Response{Status: 404,
				Body: []byte(`{"error":{"code":"not_found"}}`)}, nil
		}
		if x.ignoreDeletes {
			return Response{Status: 200, Body: cancelBody(id, o.coid, "0.00")}, nil
		}
		reduced := o.remaining
		o.status, o.updated, o.staleReads = StatusCanceled, lagCancelledAt, x.lag
		return Response{Status: 200, Body: cancelBody(id, o.coid, reduced)}, nil

	case req.Method == "GET" && req.Path == EpOrders.Path:
		if req.Query.Get("status") != StatusResting ||
			req.Query.Get("ticker") != lagTicker {
			x.t.Errorf("unexpected orders filter %v", req.Query)
		}
		x.lists++
		items := []any{}
		for _, o := range x.orders {
			switch {
			case o.status == StatusResting:
				items = append(items,
					o.record(lagTicker, StatusResting, o.remaining, o.updated))
			case o.staleReads > 0:
				o.staleReads--
				if x.staleStatus {
					items = append(items,
						o.record(lagTicker, o.status, "0.00", o.updated))
				} else {
					items = append(items,
						o.record(lagTicker, StatusResting, o.remaining, o.created))
				}
			}
		}
		return jsonPage(EpOrders, "", map[string][]any{"orders": items}), nil

	case req.Method == "GET" && strings.HasPrefix(req.Path, EpOrders.Path+"/"):
		id := strings.TrimPrefix(req.Path, EpOrders.Path+"/")
		x.gets = append(x.gets, id)
		if x.named != nil {
			return x.named(id)
		}
		o := x.find(id)
		if o == nil {
			return Response{Status: 404,
				Body: []byte(`{"error":{"code":"not_found"}}`)}, nil
		}
		return x.fresh(o), nil
	}
	x.t.Errorf("lagExchange got an unscripted %s %s", req.Method, req.Path)
	return Response{}, fmt.Errorf("unscripted %s %s", req.Method, req.Path)
}

func lagRequest(x *lagExchange, id string) []Order {
	o := x.find(id)
	return []Order{{OrderID: o.id, ClientOrderID: o.coid, Ticker: lagTicker,
		Ours: true}}
}

func sweepSEV1(res SweepResult) bool {
	for _, a := range res.Anomalies {
		if a.Class == "SWEEP_INCOMPLETE" && a.Sev == risk.SEV1 {
			return true
		}
	}
	return false
}

func ids(orders []Order) []string {
	out := make([]string, 0, len(orders))
	for _, o := range orders {
		out = append(out, o.OrderID)
	}
	return out
}

// onlyNamed fails when a DELETE or named GET reached an order outside `want`.
func onlyNamed(t *testing.T, what string, got []string, want ...string) {
	t.Helper()
	allowed := map[string]bool{}
	for _, w := range want {
		allowed[w] = true
	}
	for _, id := range got {
		if !allowed[id] {
			t.Fatalf("%s reached %s, which this sweep was not asked to cancel "+
				"(got %v); the opposite side's order is kept alive and "+
				"reported, never cancelled or re-examined (A4, M2)", what, id, got)
		}
	}
}

// The six-SEV1 reproducer, two-sided: a market stop cancels YES, then NO, while
// the list still shows each cancelled order for longer than a sweep lasts.
func TestSweepRetiresAListLaggedCancelOnTheExchangesTerminalAnswer(t *testing.T) {
	x := newLagExchange(t, 3)
	c := NewClient(x)

	yes := c.CancelAndSweep(context.Background(), lagTicker, lagRequest(x, "oY"))
	if sweepSEV1(yes) || !yes.Clean {
		t.Fatalf("the exchange's own record says oY is %s (updated %s), yet the "+
			"sweep reported clean=%v, still resting %v, SEV1 %v.\n\n"+
			"The complete list still showed oY because it lags the cancel "+
			"(lip-kaf: six such SEV1s on 2026-09-28, each 0.27-1.2 s after the "+
			"order's terminal time). An order the exchange reports cancelled "+
			"is not live and fillable (H-FAIL-3)",
			x.find("oY").status, x.find("oY").updated, yes.Clean,
			ids(yes.StillResting), sweepSEV1(yes))
	}
	if got := ids(yes.OtherOurs); len(got) != 1 || got[0] != "oN" {
		t.Fatalf("the NO order still rests and must be reported, got %v", got)
	}
	onlyNamed(t, "a YES-sweep DELETE", x.deletes, "oY")
	onlyNamed(t, "a YES-sweep named read", x.gets, "oY")
	if len(x.gets) > 1 {
		t.Fatalf("oY was read by name %d times in one sweep, want at most one",
			len(x.gets))
	}

	// The NO side, while oY is still in the lagging list.
	x.deletes, x.gets = nil, nil
	no := c.CancelAndSweep(context.Background(), lagTicker, lagRequest(x, "oN"))
	if sweepSEV1(no) || !no.Clean {
		t.Fatalf("NO sweep: clean=%v still=%v SEV1=%v, although the exchange "+
			"reports oN %s", no.Clean, ids(no.StillResting), sweepSEV1(no),
			x.find("oN").status)
	}
	onlyNamed(t, "a NO-sweep DELETE", x.deletes, "oN")
	onlyNamed(t, "a NO-sweep named read", x.gets, "oN")

	// Clearance: once the list catches up it shows neither.
	x.lag = 0
	for _, o := range x.orders {
		o.staleReads = 0
	}
	read := c.Orders(context.Background(), lagTicker, StatusResting)
	if !read.Replaces() || len(read.Orders) != 0 {
		t.Fatalf("after the lag the complete list should be empty: %v %v",
			read.Outcome, ids(read.Orders))
	}
}

// A lag inside the sweep's own retry needs no named read: the retry's list is
// already current.
func TestSweepListLagShorterThanTheRetryNeedsNoNamedRead(t *testing.T) {
	x := newLagExchange(t, 1)
	res := NewClient(x).CancelAndSweep(context.Background(), lagTicker,
		lagRequest(x, "oY"))
	if !res.Clean || sweepSEV1(res) {
		t.Fatalf("clean=%v SEV1=%v", res.Clean, sweepSEV1(res))
	}
	if len(x.gets) != 0 {
		t.Fatalf("named reads %v; the retry's complete list already showed oY "+
			"gone", x.gets)
	}
	if res.Rounds != 2 {
		t.Fatalf("rounds %d, want 2", res.Rounds)
	}
}

// The filter lagged but the record did not: the listed record itself says
// cancelled. That is the exchange's own terminal answer about that order.
func TestSweepListedTerminalRecordIsNotResting(t *testing.T) {
	x := newLagExchange(t, 5)
	x.staleStatus = true
	res := NewClient(x).CancelAndSweep(context.Background(), lagTicker,
		lagRequest(x, "oY"))
	if !res.Clean || sweepSEV1(res) {
		t.Fatalf("the requested order was listed with status %q, which is not "+
			"resting; clean=%v still=%v SEV1=%v", StatusCanceled, res.Clean,
			ids(res.StillResting), sweepSEV1(res))
	}
	if len(x.gets) != 0 {
		t.Fatalf("named reads %v for an order whose own listed record is "+
			"already terminal", x.gets)
	}
}

// Persistence control: the exchange keeps the order resting. Every read says
// so, and the sweep must still page SEV1.
func TestSweepEscalatesAnOrderTheExchangeStillCallsResting(t *testing.T) {
	x := newLagExchange(t, 0)
	x.ignoreDeletes = true
	res := NewClient(x).CancelAndSweep(context.Background(), lagTicker,
		lagRequest(x, "oY"))
	if res.Clean || !sweepSEV1(res) {
		t.Fatalf("oY really is resting; clean=%v SEV1=%v", res.Clean,
			sweepSEV1(res))
	}
	if got := ids(res.StillResting); len(got) != 1 || got[0] != "oY" {
		t.Fatalf("still resting %v, want [oY]", got)
	}
	onlyNamed(t, "a DELETE", x.deletes, "oY")
	onlyNamed(t, "a named read", x.gets, "oY")
}

// Terminal statuses the exchange uses for an order that no longer rests.
func TestSweepConfirmationAcceptsTheExchangesTerminalStatuses(t *testing.T) {
	for _, status := range []string{StatusCanceled, StatusExecuted} {
		t.Run(status, func(t *testing.T) {
			x := newLagExchange(t, 5)
			x.named = func(id string) (Response, error) {
				o := x.find(id)
				body, _ := json.Marshal(map[string]any{
					"order": o.record(lagTicker, status, "0.00", lagCancelledAt)})
				return Response{Status: 200, Body: body}, nil
			}
			res := NewClient(x).CancelAndSweep(context.Background(), lagTicker,
				lagRequest(x, "oY"))
			if !res.Clean || sweepSEV1(res) {
				t.Fatalf("a named %s record with nothing remaining is the "+
					"exchange confirming the order gone; clean=%v SEV1=%v",
					status, res.Clean, sweepSEV1(res))
			}
		})
	}
}

// Nothing but a terminal answer for THAT order in THIS market retires it.
func TestSweepConfirmationAcceptsOnlyATerminalAnswerForThatOrder(t *testing.T) {
	record := func(x *lagExchange, mutate func(map[string]any)) func(string) (Response, error) {
		return func(id string) (Response, error) {
			rec := x.find(id).record(lagTicker, StatusCanceled, "0.00", lagCancelledAt)
			mutate(rec)
			body, _ := json.Marshal(map[string]any{"order": rec})
			return Response{Status: 200, Body: body}, nil
		}
	}
	status := func(code int, body string) func(*lagExchange) func(string) (Response, error) {
		return func(*lagExchange) func(string) (Response, error) {
			return func(string) (Response, error) {
				return Response{Status: code, Body: []byte(body)}, nil
			}
		}
	}
	cases := map[string]func(*lagExchange) func(string) (Response, error){
		"404":          status(404, `{"error":{"code":"not_found"}}`),
		"500":          status(500, `{"error":{"code":"internal"}}`),
		"429":          status(429, `{"error":{"code":"too_many_requests"}}`),
		"undecodable":  status(200, `not json`),
		"null order":   status(200, `{"order":null}`),
		"no order key": status(200, `{"cursor":"","orders":[]}`),
		"transport error": func(*lagExchange) func(string) (Response, error) {
			return func(string) (Response, error) {
				return Response{}, errors.New("connection reset by peer")
			}
		},
		"resting": func(x *lagExchange) func(string) (Response, error) {
			return record(x, func(r map[string]any) {
				r["status"], r["remaining_count_fp"] = StatusResting, "12.00"
			})
		},
		"cancelled with quantity remaining": func(x *lagExchange) func(string) (Response, error) {
			return record(x, func(r map[string]any) { r["remaining_count_fp"] = "3.00" })
		},
		"no remaining field": func(x *lagExchange) func(string) (Response, error) {
			return record(x, func(r map[string]any) { delete(r, "remaining_count_fp") })
		},
		"another order": func(x *lagExchange) func(string) (Response, error) {
			return record(x, func(r map[string]any) { r["order_id"] = "oOther" })
		},
		"another market": func(x *lagExchange) func(string) (Response, error) {
			return record(x, func(r map[string]any) { r["ticker"] = "KXOTHER-26OCT08-T1" })
		},
		"empty status": func(x *lagExchange) func(string) (Response, error) {
			return record(x, func(r map[string]any) { r["status"] = "" })
		},
		"unknown status": func(x *lagExchange) func(string) (Response, error) {
			return record(x, func(r map[string]any) { r["status"] = "pending" })
		},
		"misspelt status": func(x *lagExchange) func(string) (Response, error) {
			return record(x, func(r map[string]any) { r["status"] = "cancelled" })
		},
	}
	for name, answer := range cases {
		t.Run(name, func(t *testing.T) {
			x := newLagExchange(t, 5)
			x.named = answer(x)
			res := NewClient(x).CancelAndSweep(context.Background(), lagTicker,
				lagRequest(x, "oY"))
			if res.Clean || !sweepSEV1(res) {
				t.Fatalf("a named answer of %q is not the exchange confirming oY "+
					"gone, and the list still shows it; clean=%v SEV1=%v",
					name, res.Clean, sweepSEV1(res))
			}
			if got := ids(res.StillResting); len(got) != 1 || got[0] != "oY" {
				t.Fatalf("still resting %v, want [oY]", got)
			}
		})
	}
}
