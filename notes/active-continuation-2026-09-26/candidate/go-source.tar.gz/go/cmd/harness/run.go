package main

import (
	"context"
	"errors"
	"fmt"
	"os"
	"sort"
	"time"

	"lip/harness/cfg"
	"lip/harness/hstore"
	"lip/harness/lifecycle"
	"lip/harness/num"
	"lip/harness/quote"
	"lip/harness/rest"
	"lip/harness/risk"
	"lip/harness/wsx"
)

// This file is the OWNER GOROUTINE and the loops that feed it.
//
// # Why there is exactly one owner
//
// Three of the objects it touches carry no mutex, and none of them is an
// oversight. `quote.Queue`: "It carries no mutex, exactly as core carries none
// (H-TOP-4): safety here is single-writer, and the owner goroutine is that
// writer." `core.Rig`: the measurement rig makes the same assumption, one owner
// selecting over the frame channel. `risk.Portfolio`: pure, no clock, no
// goroutine. So the book, the position model, the queue and the capacity are all
// owned HERE, by one goroutine, and every other goroutine in this process
// reaches them through a channel or not at all.
//
// # What the other goroutines are, and why each is separate
//
//   - the STORE WRITER (`hstore.Store.Run`) -- one connection, one goroutine.
//   - the MONITOR -- I2. It holds an `atomic.Pointer` and nothing else, so no
//     decision taken here can stop it. That is the fix for probebot.py's
//     defect: 2 snapshots over 6.14 hours while 61 contracts sat naked.
//   - the WS SUPERVISOR -- owns the socket's whole lifetime and its own derived
//     contexts, so a socket failure cannot reach anything else (H-FAIL-2).
//   - the PORTFOLIO POLLER -- a separate goroutine on a separate context from
//     any session, for the same reason. It keeps polling through an outage.
//   - the DISPATCHER POOL -- bounded transport workers (H-ORD-6, H-QUE-3). It is separate
//     from the owner because `rest.Create` blocks for up to `restTimeout` and
//     retries the same coid up to `retry_same_coid_max` times: an owner parked
//     inside one is an owner not publishing snapshots, and `owner_stall_s` is
//     3 seconds, so every order placed would raise a SEV1 `OWNER_STALLED`. A
//     chronic false SEV1 is how a real one stops being read.
//   - the RESULT LOOP -- drains `hstore` outcomes and the anomaly buffer.
//
// The owner therefore never blocks on I/O. Everything it does is arithmetic
// over state it already holds, plus a channel send.

// ownerTick is the floor cadence for re-evaluation in a quiet market.
//
// It is `debounce_s`, deliberately. §6.5's two brakes are both "has this
// condition held for `debounce_s`?", and a re-evaluation interval coarser than
// the debounce makes the debounce longer than §16 says it is -- silently, and
// only in the markets quiet enough that nothing else woke the loop. A busy
// market wakes it far more often, on every delivered frame.
const ownerTick = 250 * time.Millisecond

// eventBuffer and readBuffer size the hand-offs into the owner.
//
// Both are small on purpose. A deep buffer in front of a single consumer does
// not make it faster, it makes it LATE: the owner would work through a queue of
// book states that are no longer true, and §6.5 would requote against a touch
// that has already moved. `wsx.Poller` already coalesces its own overruns for
// exactly this reason -- "a queue of overdue polls against a slow endpoint is
// how a five-second cadence becomes a five-minute backlog of answers about the
// past" -- and the same argument applies one layer up.
const (
	eventBuffer = 64
	readBuffer  = 2
	// scheduleBuffer is one. A schedule read is a REPLACEMENT, not an event:
	// the newest answer supersedes every older one completely, so a queue of
	// them is a queue of answers about the past -- and §9's whole point is that
	// the schedule moves.
	scheduleBuffer   = 1
	crossCheckBuffer = 1
)

// owner is the state exactly one goroutine may touch.
type owner struct {
	r *rig
	// sd is the stop path: signals, the A9 state_event mirror, the drain and the
	// result loop. It is a collaborator rather than a set of methods here
	// because `os/signal.Notify` and `os.Exit` are the two things this file must
	// not be able to reach by accident.
	sd *shutdown
	p  cfg.Params

	// F7 samples the independent wall and monotonic readings on every owner
	// iteration. Only the owner touches this detector or its accumulated total.
	sleep               lifecycle.SleepDetector
	sleepDowntime       time.Duration
	wsCommands          chan<- wsx.Command
	crossChecks         chan<- wsx.CrossCheckRequest
	restReducer         rest.ReducerBook
	f5ResnapshotPending bool
	bookSID             int64 // current connection's orderbook_delta SID; zero until proven

	global            quote.GlobalState
	market            quote.MarketState
	programMembership programMembership

	// --- the §12 cause that is not on disk yet -------------------------------
	//
	// `lifecycle` answers every uncertain stop path with two fields, and both
	// are instructions to this loop rather than diagnostics: "BlockAdding is
	// I1's response to every uncertainty in this file... cancels, reducing
	// quotes, position polling, reconciliation and monitoring all continue while
	// it is set", and "RetryLatch asks the caller to CommitStop again"
	// (global.go:50-58, :82-89).
	//
	// Before lip-vxo neither was read anywhere in this package. `requestStop`
	// returned on a failed write, and whether the stop was ever tried again
	// depended on whether the ORIGINAL condition happened to recur -- and all
	// three of its call sites are event-driven: a portfolio read (`applyRead`),
	// a gate tick (`evaluate`) and an ack that carried a fill
	// (`applyWriteResult`). A taker fill does not recur. So one transient EIO
	// could lose a global stop for the life of the process, with the harness
	// still adding and nothing saying so.

	// stopCause is the FIRST §12 cause whose durable write has not succeeded,
	// and stopHeld is whether one is held at all.
	//
	// The first cause is kept and later ones are discarded, matching
	// `FileLatch.Ensure`'s first-writer-wins and for the reason it gives: "the
	// first durable cause is the one the operator investigates, and a later,
	// more mundane trigger -- a SIGTERM sent while winding down from a taker
	// fill -- must not overwrite the reason the harness stopped".
	//
	// `BlockAdding` and `RetryLatch` are held as ONE condition and not two,
	// because `lifecycle` produces them as one: every path that sets either sets
	// both (global.go:173-174, :213, :239, :320-321). Splitting them here would
	// admit a state this codebase never emits -- adding blocked with nothing to
	// retry -- and that state is a wedge with no exit.
	stopCause lifecycle.StopCause
	stopHeld  bool
	// stopPinged stops the retry raising its SEV1 four times a second into a
	// 256-slot buffer. The first failure is raised in full; the retries are
	// silent, and `releaseStop` says when it ended. Same argument as
	// `reducerCancelPinged`: a standing condition is worth saying once.
	stopPinged  bool
	stopRetries uint64

	// signalCause is a SIGTERM or SIGINT whose durable write failed, held
	// SEPARATELY from `stopCause` and for a different reason.
	//
	// `stopCause` is what gets written; this is what gets a DRAIN PERMIT once
	// something is written. The two cannot be one field: a taker fill may
	// already be held when the signal arrives, and first-writer-wins would then
	// discard the signal's cause -- correctly, because the taker fill is the
	// reason the operator investigates, and incorrectly for the exit, because
	// the operator still asked for the process to end.
	//
	// Without this, `SignalController.Handle` issues no permit on a failed write
	// (drain.go), `onSignal` falls back to `BeginUnplanned` (shutdown.go), and
	// `DrainTracker` upgrades an unplanned drain only when handed a valid permit
	// -- which nothing in the retry path ever mints. H-HALT-3's SIGTERM would
	// stop adding, wind down, reach flat and then idle forever.
	signalCause lifecycle.StopCause
	signalHeld  bool

	// --- §6.5's two clocks, per side ---------------------------------------
	//
	// They are separate measurements and not one reused twice.
	// `RequoteInput.StrandedFor` says why: "Debouncing the stranded brake
	// against TouchHeld would let a touch that flickers every 200ms reset the
	// timer forever, so the one rule written to rescue an order nobody is
	// trading against would be defeated by exactly the churn that stranded it."

	// touchPrice is the external touch this side was last seen at, and
	// touchSince is when it arrived there. H-Q-7 debounces against this.
	touchPrice [2]int
	touchFound [2]bool
	touchSince [2]time.Duration

	// strandedSince is when our order first went `stale_bid_ticks` or more from
	// the touch, and strandedNow whether it still is. H-Q-8 debounces against
	// the CONDITION's age, not the price's.
	strandedSince [2]time.Duration
	strandedNow   [2]bool

	// --- the write path ----------------------------------------------------

	capacity quote.Capacity
	capAt    time.Duration
	// capCarry is the fractional token accrual `refillWrites` carries between
	// calls. `write_rate` is 5/s and the owner ticks at 250 ms, so every single
	// tick accrues 1.25 tokens: dropping the fraction would round the §16 write
	// rate down to 4/s and nothing would say so.
	capCarry float64
	coidSeq  uint64

	// inflight tracks every request occupying the bounded transport pool.
	// The owner alone grants work; reducers retain a reserved worker slot.
	inflight       []*writeRequest
	retries        []writeRequest
	throttled      bool
	throttleAt     time.Duration
	throttleFirst  time.Duration
	throttlePinged bool

	// startupTrades is the trade id of every fill §7.5 saw on the account,
	// frozen out of the Adoption that licensed this process to leave STARTING.
	//
	// It is the HISTORY half of the canary rule's boundary, and it is read-only
	// from installation onwards. Nothing adds to it: a trade that turns up after
	// the adoption is by definition not one the adoption saw, and letting the
	// live path widen the set would make every fill its own excuse.
	startupTrades map[string]struct{}

	// pending is every create this process has made that the orders walk has
	// not listed back yet -- unknown AND acked alike. See `pendingOrder`.
	//
	// An entry leaves ONLY when a complete orders walk LISTS its coid, at which
	// point the order is in `Portfolio.LiveOrders` and counting it here as well
	// would double it. Absence from a walk is never the trigger: H-ORD-2a
	// deleted the exhaustive-read proof of a negative, and "the order is not in
	// the list" is that proof wearing a different hat.
	pending map[string]pendingOrder

	// --- §9's schedule, as READ ---------------------------------------------
	//
	// `harness-spec.md` §9 opens with a source table naming where each of these
	// comes from: `market.close_time` from `/markets/{ticker}` ("trading stops;
	// position settles") and `program.end_date` from
	// `/incentive_programs?status=active` ("reward accrual stops"). It adds that
	// "`close_time` may fall before or after `end_date`. Neither is assumed
	// static" -- which is why these are polled at `schedule_poll_s` rather than
	// read once, and why none of them is a config field.
	//
	// Every one of them starts UNKNOWN, and unknown is not "far away".
	// `quote.MarketInput.HasClose` is explicit about the difference: "a market
	// whose close_time we do not know is one we cannot enforce a lead on, and
	// H-CLOSE-0 makes that the caller's problem to escalate rather than this
	// function's to assume away."
	closeAt  time.Time
	hasClose bool
	// canCloseEarly is H-CLOSE-4's flag, and on this exchange it is the common
	// case rather than the exception -- 192 of 200 active LIP programmes on
	// 2026-08-07. It selects the operator's early backoff, not a refusal.
	canCloseEarly bool
	// tradingClosed is the close OBSERVED. §5.2 is precise that this, and not
	// the arithmetic, is authoritative: a `can_close_early` market settles
	// before `close_time` and no lead computed from `close_time` sees it coming.
	tradingClosed bool
	// scheduleRead is when a COMPLETE schedule read last landed. H-CLOSE-0
	// requires the schedule be sampled at least twice within the lead it
	// enforces, so a schedule that has stopped arriving is itself a condition.
	scheduleRead   time.Duration
	scheduleEver   bool
	schedulePinged bool

	// --- what the loops have established -----------------------------------

	// reduceNoted is the reduce requests observed SINCE THE LAST EVALUATION, and
	// it is cleared at the end of every one.
	//
	// It is not a latch, and an earlier version of this field being one was a
	// wedge: `wsx.Gate` already holds the sticky reduce -- `Gate.Reducing`
	// answers it and the gate is what clears it when the condition that set it
	// goes away -- so a second latch here could only ever be an unclearable
	// copy. One disconnect would have sent this market to REDUCING for the life
	// of the process, and the socket coming back would not have brought it out.
	//
	// What the field IS for is the reduce requests that do NOT come from the
	// gate: H-POS-2's position drift, arriving through `ApplyPortfolio`. Those
	// need no latch of their own, because `quote.NextMarket` holds REDUCING
	// itself until `q` reaches zero AND nothing is stopping the market.
	reduceNoted bool

	// reducerCancelPinged stops a refused reducing-side cancel from producing
	// one anomaly per 250 ms tick. The condition is a programming error rather
	// than a market event, so it is worth saying once and worth not saying four
	// times a second into a 256-slot buffer.
	reducerCancelPinged [2]bool

	// cancelConfirmed is, per side of the one market, H-FAIL-3's own licence:
	// a COMPLETE verifying read found NOTHING OF OURS resting there.
	//
	// It is the only thing that ends a cancellation obligation, and it has to be
	// held because `risk.Portfolio.LiveOrders` does not learn it. `LiveOrders`
	// is replaced wholesale from a complete ORDERS WALK (H-POS-4) and the next
	// one is up to `position_poll_s` away, so for those five seconds `atRisk`
	// still reports the order we have just watched the exchange confirm gone --
	// and `evaluate` would reissue the cancel on every one of the twenty ticks
	// in between. Each of those is a DELETE for an id the exchange no longer
	// has plus a full verifying walk, spending the §16 write budget the reducer
	// shares.
	//
	// It is set ONLY from `writeResult.Absent`, which `dispatch.go` grants only
	// for a complete read that found none of the requested orders AND no other
	// order of ours on that side. It is cleared by anything that could put one
	// back: a create on that side that may have left quantity live, and a
	// complete orders walk started after the latest cancel sweep, which is
	// when our own model becomes authoritative again. Both clears are generous
	// on purpose -- a redundant
	// cancel costs one write, and a missed one costs an adding order left
	// resting in a market the harness has stopped adding in.
	cancelConfirmed [2]bool
	// absentOrders are ids still present in the last portfolio orders walk but
	// subsequently proved absent by a complete cancel sweep. A replacement
	// create clears cancelConfirmed, so that side-wide flag cannot also be the
	// sizing rule: it would resurrect the cancelled reducer before the next
	// portfolio walk. A new complete walk started after the sweep replaces this
	// older evidence; a previously in-flight walk cannot supersede it.
	absentOrders map[string]struct{}
	// A cancel sweep proves absence, but the old order may have filled just
	// before its DELETE. Until a subsequent complete portfolio cycle started
	// after the sweep, q may be too large for a replacement reducer. Hold all
	// placements while that uncertainty exists; cancels still run.
	awaitCancelTruth bool
	cancelTruthAfter time.Duration
	// The latest Gate-issued token and the poller's input are retained so a
	// cancel can request an immediate account reconciliation on this generation.
	reconcileToken   wsx.ReconcileToken
	reconcileOut     chan<- wsx.ReconcileToken
	reconcilePending bool

	// --- H-Q-4a's continuous gate-failure episode ---------------------------
	//
	// `gate_fail_debounce_s` was configured, defaulted and unit-tested before
	// `lip-732` and had no production reader at all. H-Q-4a is what reads it:
	// "after gate_fail_debounce_s (30s) of continuous gate failure, cancel and
	// exchange-confirm every adding order. If q != 0, keep only the
	// aggregate-capped reducer."
	//
	// gateFailSince is, per market, the monotonic instant the CURRENT unbroken
	// run of accepted, current-generation, NON-qualifying books began. No entry
	// means no episode is open.
	//
	// Three properties, and each of them is a way this goes silently wrong:
	//
	//   - The stamp comes from the injected clock (`wsx.Stamp.Mono`) and is
	//     compared against `owner.evaluate`'s `now`, which is `exchange.Mono`.
	//     Both are monotonic. F21's clock step moves the WALL clock and must not
	//     shorten, extend or reset this interval, and a wall-derived stamp here
	//     would let a one-hour NTP correction retire an adding order instantly
	//     or hold one live for an hour.
	//   - A continuing failure does NOT move the start. H-Q-4a says *continuous*
	//     failure, so a market publishing a thin book four times a second must
	//     accumulate one 30-second interval, not restart a 30-second interval
	//     every 250 ms -- which would make the rule unreachable in exactly the
	//     busy market it matters in.
	//   - Only book evidence writes here. `wsx.Gate.BookCurrent` is separate
	//     from `Actionable` for this reason: a stale portfolio walk must not be
	//     able to start, extend or clear a book's episode.
	gateFailSince map[string]time.Duration
	// gateFailPinged dedupes the SEV2 to one per EPISODE and re-arms when a
	// qualifying book clears it. Same argument as `pnlPinged` and
	// `reducerCancelPinged`: a standing condition is worth saying once, and at
	// four evaluations a second into a 256-slot buffer it is worth not saying
	// two hundred times a minute -- which evicts the anomaly the operator needs.
	gateFailPinged map[string]bool

	// F16 episodes are owned by this goroutine and read only accepted position truth.
	inventoryStuck    inventoryStuckTracker
	operationsDisk    operationsDiskGuard
	storeHealth       storeHealthGuard
	fundingStopPinged bool
	rejects           rejectWindow
	postOnlyCrossSeen map[string]bool
	listedBindings    map[string]string

	// sweptOrders is every order of OURS that a cancel's VERIFYING READ found
	// resting and that no complete orders walk has listed into `risk.Portfolio`
	// yet, keyed by exchange order id.
	//
	// It exists because `build` could previously only cancel what
	// `Portfolio.LiveOrders` held, and `LiveOrders` is replaced wholesale from a
	// complete orders walk (H-POS-4) that is up to `position_poll_s` away. So an
	// adding order that was created between two walks -- acked, UNKNOWN, or
	// simply young -- was in every aggregate CAP (`pending`, and therefore
	// `atRisk`) and in no cancel REQUEST: H-Q-4a's expiry would raise the
	// obligation to retire it and `build` would answer "nothing of ours rests on
	// this side" and drop it. The order stayed live and fillable through the
	// whole gated-out interval, which is precisely HR-012's hole reached one
	// layer down.
	//
	// `rest.SweepResult` already reports the two sets a complete verifying read
	// establishes -- `StillResting` for what we asked to cancel and `OtherOurs`
	// for everything else of ours in the ticker -- and `OtherOurs` is exactly
	// where such an order turns up. It is REPLACED WHOLESALE from a complete
	// read and never edited from a partial one (H-PAGE-1: stale, never empty),
	// which is what makes "the order is gone" a fact the exchange stated rather
	// than one we inferred from silence (H-FAIL-3, H-ORD-2a).
	//
	// It deliberately contributes NO quantity to `atRisk`. Every order in it is
	// also in `LiveOrders` or in `pending`, so counting it again would double a
	// size the aggregate caps are evaluated against (H-Q-5b) -- and an
	// overstated reducer aggregate is a reducer that never gets placed. What it
	// contributes is the IDENTIFIER, which is the half that was missing.
	sweptOrders map[string]rest.Order

	// --- H-HALT-5's ledger ---------------------------------------------------

	// pnl is the trading P&L: seeded from the durable `our_fill` history at
	// startup and advanced by every owned fill this process sees afterwards.
	//
	// The owner holds it and nothing else has a reference. `risk.TradingPnL` is
	// a pure accumulator with no clock, no lock and no I/O, which is what makes
	// one owner goroutine sufficient for it -- the same argument this file makes
	// for `risk.Portfolio`.
	pnl *risk.TradingPnL
	// pnlTickers is every market the ledger has taken a fill for.
	//
	// `Evaluate` refuses outright when the ledger holds a market the caller did
	// not ask about, because that market's cash would otherwise be missing from
	// the total and a missing contribution understates a loss. Keeping the set
	// here means the owner always asks about all of them, so that refusal stays
	// a backstop rather than the normal path.
	pnlTickers map[string]struct{}
	// pnlQExch is the LATEST COMPLETE authoritative position per market, and it
	// is deliberately not `Portfolio.Q`.
	//
	// `q_local` is advanced by ACKS as well as by fills -- `Portfolio.settle`
	// applies max(ackCum, fillCum) -- so a ledger built from fills alone would
	// disagree with it for a reason that is not a basis hole at all, and every
	// such disagreement would refuse to evaluate the trigger. H-POS-1's
	// overwrite is the reading H-HALT-5 wants checked against. An INCOMPLETE
	// walk contributes nothing and leaves the previous figure standing, which is
	// H-PAGE-1's "stale, never empty" applied here.
	pnlQExch map[string]num.Qty
	// pnlQKnown is whether any complete positions walk has landed yet. Until one
	// has there is no authoritative figure to check the ledger against, so the
	// trigger is simply not evaluated -- which is not-fired, and is not safe.
	pnlQKnown bool
	// pnlPinged dedupes the SEV2 once per market per unavailable EPISODE and
	// re-arms when that market's mark or basis recovers.
	//
	// Same shape and same argument as `ORDER_UNKNOWN`'s and
	// `FILL_UNCLASSIFIABLE`'s: a standing condition is worth saying once, and at
	// four evaluations a second into a 256-slot buffer it is worth not saying
	// two hundred times a minute -- which would evict every other anomaly in the
	// buffer, including the one the operator needs.
	pnlPinged map[string]struct{}
	// pnlKilled is whether the floor has already fired, and it is never cleared.
	//
	// Without it the breach re-raises its SEV1 and re-enters the stop funnel on
	// every tick for the life of the process -- the loss does not go away
	// because the harness stopped adding to it, and `pnl <= pnl_kill` stays true
	// afterwards. It is also the field that makes the halt IRREVERSIBLE in
	// memory as well as on disk: a durable pnl halt is never undone when the
	// mark later disappears, and a later refusal to evaluate must not read as
	// the condition clearing.
	pnlKilled bool

	// --- §12's out-of-band halt -----------------------------------------------

	// harnessStopSeen and harnessStopUnreadable dedupe the sentinel's two
	// anomalies to one per condition, and neither is ever cleared.
	//
	// Never cleared is the property, not an oversight. Removing the file must
	// not resume adding: the stop is durable the moment `commitStop` writes it,
	// H-HALT-4 makes it survive the process, and §10.4 makes clearing it an
	// OPERATOR action through the latch rather than through the sentinel. A flag
	// that reset when the file vanished would make `rm` an undo, and the
	// operator who created the file to stop a harness at 3am would find it
	// trading again by tidying up.
	//
	// Without the dedupe the condition is standing and the raise is not: a file
	// that stays put would put a SEV2 into a 256-slot buffer four times a second
	// and re-enter the stop funnel on every tick, evicting the anomalies the
	// operator actually needs to read.
	harnessStopSeen       bool
	harnessStopUnreadable bool

	snapSeq uint64
}

// pendingOrder is one create this process has made that the orders walk has not
// listed back yet, held for its risk contribution.
//
// It covers BOTH outcomes that leave quantity live, and the second one is the
// one an earlier revision of this file missed:
//
//   - UNKNOWN, where H-ORD-2 clause 6 keeps the maximum possibly-live quantity
//     in every cap until the order is positively resolved;
//   - ACKED, where the order demonstrably exists and simply is not in
//     `risk.Portfolio` yet, because `Portfolio.ReplaceOrders` is wholesale from
//     a complete orders walk (H-POS-4) and the next one is up to
//     `position_poll_s` away.
//
// Leaving the acked case out is not a reporting gap, it is a size failure.
// `restingOn` feeds `RequoteInput.HasOurs` and `OurSize`, so an acked order the
// aggregate cannot see makes the side read EMPTY -- and §6.5's answer to an
// empty side is presence restoration, every tick, with no debounce (a presence
// gap is revenue, so `Decide` deliberately does not wait). Measured on the
// composed harness: one +8 position produced ten identical 8-contract exits in
// about three seconds, bounded only by `write_burst`, none cancelled and none
// filled -- 80 contracts of reducer against 8 contracts of inventory. H-Q-5a
// caps a reducer at |q| and A12 says no fill sequence may change the sign of q
// via a reducer; that sequence can.
type pendingOrder struct {
	side  quote.Side
	cents int
	// qty is what this order may have live: `CreateResult.MaxLive`, which is
	// the requested count for anything that is not a definite rejection. It is
	// the conservative figure on purpose -- H-Q-5b counts RESTING + SENDING +
	// UNKNOWN + unconfirmed-cancel, and every cap is evaluated against that.
	qty num.Qty
	at  time.Duration
	// acked distinguishes the two cases for ESCALATION only. Both occupy the
	// aggregate identically; only an unresolved one is worth waking an operator
	// about, because an acked order that has not appeared in a walk yet is
	// simply younger than the poll.
	acked  bool
	pinged bool
	// id is the exchange order id the acknowledgement carried, and "" when the
	// create ended UNKNOWN and there is none.
	//
	// It is what makes an acked-but-unlisted order CANCELLABLE. Without it the
	// only cancel target `build` had was `Portfolio.LiveOrders`, so a stop
	// raised between two orders walks -- H-Q-4a's expiry, H-CLOSE-3's final
	// cancel, A8 -- could name the obligation and not the order, and the
	// quantity stayed live for up to `position_poll_s` with the harness
	// believing it had asked for it back.
	//
	// An UNKNOWN create has no id here and that is not a gap: H-ORD-2a forbids
	// inferring anything from absence, so it is resolved POSITIVELY, either by
	// the orders walk listing the coid or by the sweep's verifying read finding
	// the order -- which is what `sweptOrders` catches.
	id string
}

func newOwner(r *rig, sd *shutdown) *owner {
	o := &owner{
		r:                 r,
		sd:                sd,
		p:                 r.cfg.Params,
		global:            quote.Starting,
		market:            quote.Idle,
		programMembership: programMembership{ticker: r.cfg.Ticker},
		operationsDisk:    operationsDiskGuard{enabled: true, db: r.cfg.Paths.DB, journal: r.cfg.Paths.AnomalyLog, evidence: r.qualificationPath},
		capacity:          r.cap,
		pending:           make(map[string]pendingOrder),
		absentOrders:      make(map[string]struct{}),

		gateFailSince:  make(map[string]time.Duration),
		gateFailPinged: make(map[string]bool),
		sweptOrders:    make(map[string]rest.Order),

		pnl:        risk.NewTradingPnL(),
		pnlTickers: make(map[string]struct{}),
		pnlQExch:   make(map[string]num.Qty),
		pnlPinged:  make(map[string]struct{}),
	}

	if r.boot.BlockAdding || r.boot.RetryLatch {
		// `rig.boot`'s two answers, honoured from the first tick rather than
		// held as diagnostics -- which is what the field's own comment asks for.
		//
		// The latch READ failed, so `NewGlobalController` bootstrapped LATCHED
		// and asked for the write to be retried. There is no cause to retry it
		// with, because nothing in this process decided to stop: this one is
		// synthesised for exactly that, and it is not a fiction -- the harness
		// really is halting, and it is halting because the latch could not be
		// read.
		//
		// `Ensure` is first-writer-wins, so if a record IS on disk this retry
		// does not overwrite the reason the previous incarnation stopped; it
		// completes the parent-directory sync that the failed read could not
		// confirm had ever happened. If nothing is on disk it writes one, and
		// a halt this process is already in becomes a halt that survives it.
		o.holdStop(lifecycle.StopCause{
			Trigger: "latch_unreadable", TsMillis: r.ex.NowMs(),
		})
	}
	return o
}

// serve is the process. It performs §7.5, installs the adoption, starts every
// other goroutine and then owns the loop until the context ends.
//
// Named `serve` rather than `run` because `rig.run` is §15's run handle -- the
// licence every record beneath it requires -- and a method shadowing it would
// make `r.run` mean two different things one keystroke apart.
func (r *rig) serve(ctx context.Context) error {
	return r.serveWithShutdown(ctx, newShutdown(r), nil)
}

// serveWithShutdown keeps signal delivery and the final exit injectable for
// composed lifecycle tests. Production supplies the real shutdown and signals.
func (r *rig) serveWithShutdown(ctx context.Context, sd *shutdown, signals <-chan os.Signal) error {
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()
	if r.qual != nil {
		go r.runQualificationCheckpoints(ctx)
	}

	o := newOwner(r, sd)

	// The monitor starts FIRST, before the startup walk and before anything can
	// place an order. A5's obligation is to have a sample for every selected
	// market at every tick, and the interval this harness most needs observed is
	// the one where it is deciding what it inherited.
	monTick := time.NewTicker(time.Second)
	defer monTick.Stop()
	go r.mon.run(ctx, monTick.C)

	// The result loop starts before the first submission that is not the run
	// row, so no record's outcome sits unclaimed. It also drains `r.deferred` --
	// results that arrived while construction was waiting for the run handle.
	go func() {
		if err := sd.runResults(ctx); err != nil && ctx.Err() == nil {
			r.anom.raise(risk.Anomaly{
				Class: "RESULT_LOOP_EXIT", Sev: risk.SEV1,
				Text: fmt.Sprintf("the store result loop returned %v; from here "+
					"no lost record raises its SEV1 and no anomaly reaches "+
					"either journal", err),
			})
		}
	}()

	// Alerting is independent of startup and begins with an immediate Step.
	// In particular, a startup walk which stalls or fails must not prevent a
	// pending alert from a previous process being retried.
	if err := r.startAlerts(ctx); err != nil {
		return err
	}

	adoption, err := o.startup(ctx)
	if err != nil {
		return err
	}
	o.install(adoption)

	events := make(chan wsx.Event, eventBuffer)
	reads := make(chan wsx.PortfolioRead, readBuffer)
	tokens := make(chan wsx.ReconcileToken, 1)
	commands := make(chan wsx.Command, 1)
	o.wsCommands = commands
	writes := make(chan writeRequest, dispatchWorkers)
	results := make(chan writeResult, dispatchWorkers)

	go func() {
		// The supervisor never returns because of a socket; only the process
		// context ends it. Its error is therefore always the context's.
		if err := r.sup.Run(ctx, commands, events); err != nil && ctx.Err() == nil {
			r.anom.raise(risk.Anomaly{
				Class: "WS_SUPERVISOR_EXIT", Sev: risk.SEV1,
				Text: fmt.Sprintf("the websocket supervisor returned %v while "+
					"the process context was still live; the book feed is gone "+
					"and every market is non-actionable until it comes back", err),
			})
		}
	}()
	go func() {
		if err := r.poll.Run(ctx, tokens, reads); err != nil && ctx.Err() == nil {
			r.anom.raise(risk.Anomaly{
				Class: "PORTFOLIO_POLLER_EXIT", Sev: risk.SEV1,
				Text: fmt.Sprintf("the portfolio poller returned %v; position "+
					"truth stops advancing from here, so it ages out and "+
					"H-FAIL-4 stops all dispatch, which is the correct end "+
					"state but not a recoverable one", err),
			})
		}
	}()
	// The dispatcher is handed the RESERVATION OUTCOMES it needs and never the
	// store's FIFO itself. `runResults` is the sole consumer of `TakeResults`,
	// because it is the only thing that must see every result: a second consumer
	// racing it would sometimes take a terminal outcome belonging to another
	// record, and that record's SEV1 `STORE_RECORD_REJECTED` would never be
	// raised -- `reject.go`'s whole argument is that the loss is observable
	// exactly once, per record, from `Result.Err`.
	go r.dispatchLoop(ctx, writes, sd.Permits(), results)

	// §9's schedule poll. It is a SEPARATE goroutine for the same reason the
	// portfolio poller is: it is a REST read that must keep answering while the
	// socket is down, and it must not be able to park the owner. Its cadence is
	// `schedule_poll_s`, which `cfg.Validate` has already asserted is at least
	// twice per `final_lead` -- H-CLOSE-0's sampling rule, checked as arithmetic
	// rather than discovered at the close (HR-017).
	schedules := make(chan rest.ScheduleResult, scheduleBuffer)
	go r.scheduleLoop(ctx, schedules)
	programs := make(chan rest.ProgramsResult, 1)
	go r.programLoop(ctx, programs)
	balanceThrottles := make(chan *rest.RateLimitError, 1)
	go r.balanceLoop(ctx, balanceThrottles)

	crossChecks := make(chan wsx.CrossCheckRequest, crossCheckBuffer)
	crossResults := make(chan crossCheckResult, crossCheckBuffer)
	o.crossChecks = crossChecks
	go r.crossCheckLoop(ctx, crossChecks, crossResults)

	// The drain runs on its own goroutine, fed observations by this one.
	//
	// It is separate because it is the only code in this process that may end
	// it, and the observation it acts on has to be an ANSWER: `TruthKnown`,
	// `AnyInventory` and `AnyLiveOrder` are all owner state, and a drain that
	// reached for them itself would be reading a position model with no mutex
	// from a second goroutine. So the owner supplies the facts and the drain
	// supplies the authority, and neither can perform the other's half.
	observations := make(chan lifecycle.DrainObservation, 1)
	go func() {
		if err := sd.drainLoop(ctx, observations); err != nil && ctx.Err() == nil {
			r.anom.raise(risk.Anomaly{
				Class: "DRAIN_LOOP_EXIT", Sev: risk.SEV1,
				Text: fmt.Sprintf("the drain loop returned %v; H-HALT-3's "+
					"escalation has stopped and no exit can now be authorised, "+
					"so a wound-down harness will idle rather than finish", err),
			})
		}
	}()

	if signals == nil {
		var stopSignals func()
		signals, stopSignals = installSignals()
		defer stopSignals()
	}

	tick := time.NewTicker(ownerTick)
	defer tick.Stop()
	// Establish F7's baseline before the first owner iteration. The first
	// sample cannot declare a gap by itself.
	o.observeSleep(r.ex.NowMs(), r.ex.Mono(), tokens)

	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case err := <-r.qualErrors:
			return fmt.Errorf("qualification evidence failed: %w", err)

		case ev := <-events:
			o.applyEvent(ev, tokens)

		case read := <-reads:
			o.applyRead(read)

		case res := <-results:
			o.applyWriteResult(res)

		case sch := <-schedules:
			o.applySchedule(sch)

		case prog := <-programs:
			o.applyProgramMembership(prog)

		case throttle := <-balanceThrottles:
			o.noteRESTThrottle(throttle)

		case check := <-crossResults:
			o.applyCrossCheck(check)

		case sig := <-signals:
			o.applySignal(sig)

		case <-tick.C:
		}

		now := r.ex.Mono()
		o.observeSleep(r.ex.NowMs(), now, tokens)
		o.evaluate(now)
		o.pump(now, writes)
		o.publish(now)
		o.offerDrain(observations)
	}
}

// applySignal hands one signal to the controller and folds back what it decided.
//
// This function does not exit, does not cancel a context and does not stop a
// loop. H-HALT-3: SIGTERM enters WINDING_DOWN and keeps running until drained,
// and `drain_timeout_h` escalates rather than exiting. The exit, if it ever
// happens, is authorised by the drain and by nothing else.
func (o *owner) applySignal(sig os.Signal) {
	known := o.truthKnown()
	eff := o.sd.onSignal(sig, quote.GlobalInput{
		State:         o.global,
		Latched:       o.r.ctrl.Latched(),
		TruthReadable: known,
		Reconciled:    known,
		Stop:          true,
		RiskKnown:     known,
		AnyInventory:  o.anyInventory(),
		AnyLiveOrder:  o.anyLiveOrder(),
	})
	if !eff.Recognised {
		// Not ours. It stops nothing and blocks nothing -- a controller that
		// acted on any signal would act on SIGWINCH.
		return
	}
	if !eff.Decision.Committed {
		// H-HALT-3's stop was decided and could not be made durable.
		// `SignalController.Handle` commits before it advances, so an
		// uncommitted decision here IS a failed latch write, and its
		// `BlockAdding`/`RetryLatch` are the same two answers `commitStop`
		// honours. Honouring them matters MORE here than anywhere else: a
		// signal is delivered once. There is no standing condition left to
		// recur, so a SIGTERM dropped at this line is a SIGTERM this process
		// never acts on -- while `SignalController.Handle`'s own contract
		// promises that on a failed write "the harness still stops adding and
		// still drains". The drain has already begun (`onSignal`); this is the
		// stopping-adding half, and the retry that makes it durable.
		o.holdStop(eff.Cause)
		o.holdSignal(eff.Cause)
		// Already reported. `onSignal` raised this commit's own SEV1 through
		// `eff.Anomalies`, and the first retry would otherwise raise the same
		// failed write a second time.
		o.stopPinged = true
		return
	}
	o.global = eff.Decision.State
}

// offerDrain hands this tick's facts to the drain without ever blocking.
//
// A dropped observation is not a lost one: the next tick produces another 250 ms
// later, and the drain's escalation is paced in hours. Blocking here would park
// the owner on the one goroutine whose job is to outlive it.
func (o *owner) offerDrain(observations chan<- lifecycle.DrainObservation) {
	select {
	case observations <- lifecycle.DrainObservation{
		TruthKnown:   o.truthKnown(),
		AnyInventory: o.anyInventory(),
		AnyLiveOrder: o.anyLiveOrder(),
	}:
	default:
	}
}

// startup is §7.5, retried indefinitely with backoff.
//
// There is no bounded-attempt exit and the absence is the rule: "a bounded retry
// that eventually stops is a process sitting next to inventory it decided not to
// look at again." The only thing that ends this loop is a complete adoption or
// the process context.
func (o *owner) startup(ctx context.Context) (lifecycle.Adoption, error) {
	for {
		att := o.r.start.Step(ctx, time.Now())
		o.r.anom.raiseAll(att.Anomalies)
		o.sd.mirrorGlobal(o.global, att.Decision)
		if att.Decision.Committed {
			o.global = att.Decision.State
		}

		if att.Adoption != nil {
			return att.Adoption, nil
		}
		if !att.Retry {
			// `Attempt.Retry` is documented as ALWAYS true on failure, so this
			// branch is unreachable by construction. It is written anyway
			// because the alternative to reaching it is spinning on a
			// coordinator that has told us to stop, and a busy loop against a
			// failing exchange is worse than a refusal.
			return nil, fmt.Errorf("startup declined to retry: %w", att.Err)
		}
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		case <-time.After(att.After):
		}
	}
}

// install replaces the placeholder model with what §7.5 actually read.
//
// Everything here comes from the Adoption and nothing is derived a second time.
// The portfolio is seeded from the exchange with every kept order installed; the
// market states are the adoption's, so a held market starts REDUCING (§7.5 step
// 6) rather than being re-derived from a `q` this function would have to guess
// the provenance of.
func (o *owner) install(a lifecycle.Adoption) {
	o.r.pf = a.Portfolio()
	o.global = o.r.start.State()
	if st, ok := a.States()[o.r.cfg.Ticker]; ok {
		o.market = st
	}
	// The history/live boundary, taken from the adoption that licensed this
	// process to leave STARTING. Installed BEFORE anything below can raise, and
	// long before the first poll: `serve` starts no reader until `install`
	// returns, so there is no window in which a live fill could be classified
	// against an empty baseline.
	o.startupTrades = a.StartupTrades()
	o.recordBackfilled(a.OwnedFills())
	o.seedPnL(a.OwnedFills())
	o.r.anom.raiseAll(a.Anomalies())
	o.recordFundingLimits()

	sum := a.Summary()
	o.r.anom.raise(risk.Anomaly{
		Class: "STARTUP", Sev: risk.SEV3, Ticker: o.r.cfg.Ticker,
		Text: fmt.Sprintf("run %s adopted %d order(s), cancelled %d stale, saw "+
			"%d foreign order(s) and %d foreign fill(s); balance %s, managed %v, "+
			"excluded %v, reducing %v. Global state is %s and %s is %s",
			o.r.runID, sum.AdoptedOrders, sum.CancelledStale, sum.ForeignOrders,
			sum.ForeignFills, sum.Balance, sum.Managed, sum.Excluded,
			sum.Reducing, o.global, o.r.cfg.Ticker, o.market),
	})
}

// recordBackfilled writes §7.5's owned history as `our_fill` rows with
// `backfilled = true`.
//
// Nothing else ever will, for the fills INSIDE `backfill_h`. `risk.Seed` marks
// every one of these trade ids seen in the position model, so the first live
// fills walk deduplicates them away and they never reach `applyRead`. Before
// this, an adoption's whole owned history was read, classified, seeded, used to
// decide REDUCING, and then dropped: `our_fill` began at the first fill this
// incarnation happened to watch land, and H-ORD-6 makes that table the join
// against `rig.db`.
//
// The history OUTSIDE the window is the other half and it is not this function's
// (`lip-da6`). §7.5 never asked for those fills, so they are not in the slice
// passed here; only the live walk's zero `since` ever reports them, and
// `applyRead` writes them from `PortfolioEffects.BackfilledFill` with the same
// `true`. Three call sites write `our_fill` and each owns a disjoint set of
// trade ids: this one the in-window history, `BackfilledFill` the out-of-window
// history, and `OwnedFill` what this incarnation actually traded.
//
// `backfilled` is the column that keeps the two honest. These rows are what we
// INFERRED from a walk over the past, not what we observed happening, and an
// analysis that cannot tell them apart is one that reads a restart as a burst
// of trading.
func (o *owner) recordBackfilled(fills []rest.Fill) {
	if len(fills) == 0 {
		return
	}
	events, err := lifecycle.ConvertFills(fills)
	if err != nil {
		// Unreachable by construction: §7.5 converted this same slice and
		// refused to produce an Adoption when it could not. Written anyway
		// because the alternative to reaching it is a silent `_ = err` on the
		// one table that joins our fills to the public tape.
		o.r.anom.raise(risk.Anomaly{
			Class: "FILL_NOT_RECORDED", Sev: risk.SEV1, Ticker: o.r.cfg.Ticker,
			Text: fmt.Sprintf("the adoption's %d owned fill(s) did not convert "+
				"(%v), so none of the history this process inherited reaches "+
				"our_fill; H-ORD-6 makes trade_id the join against rig.db and "+
				"a backfilled fill that is not recorded is one no later "+
				"analysis can find", len(fills), err),
		})
		return
	}
	for _, f := range events {
		if _, err := o.r.store.RecordFill(o.r.run, f, o.r.ex.NowMs(),
			true); err != nil {

			o.r.anom.raise(risk.Anomaly{
				Class: "FILL_NOT_RECORDED", Sev: risk.SEV1, Ticker: f.Ticker,
				Text: fmt.Sprintf("the adopted fill %s on order %s could not be "+
					"submitted to the store (%v); it is history we read at "+
					"startup and nothing polls for it again, so this row is "+
					"lost rather than late", f.TradeID, f.OrderID, err),
			})
		}
	}
}

// seedPnL builds H-HALT-5's ledger from every fill that is already known.
//
// Two sources, and they overlap deliberately.
//
// `our_fill` is the DURABLE history: every row, every run, both provenances. No
// filter, and the reader takes no argument to filter by. A position adopted at
// startup was PAID FOR BY AN EARLIER RUN, so a ledger restricted to this run's
// rows would hold inventory it has no cost for -- and the check against the
// authoritative quantity would then refuse to evaluate the trigger for the rest
// of the process's life. Restricting by `backfilled` fails the same way.
//
// The adoption's own fills are the ones §7.5 has just read and whose rows are
// still in flight to the store writer, so the query above cannot be relied on to
// contain them yet. `TradingPnL.Apply` is idempotent by trade id, so offering
// the same fill from both sources costs nothing and missing it from one of them
// costs the basis.
//
// The read happens HERE, once, inside `install`, and never from a tick: the
// owner drives a 250 ms loop and a SQLite query on that path would put the
// store's latency inside the quoting decision.
func (o *owner) seedPnL(adopted []rest.Fill) {
	rows, err := o.r.store.Reader().Fills()
	if err != nil {
		// Not fatal, and not silent. The ledger continues from the adoption
		// alone, which means any inventory older than it has no basis -- and the
		// authoritative-quantity check turns that into a refusal to evaluate
		// rather than into a wrong number.
		o.r.anom.raise(risk.Anomaly{
			Class: "PNL_BASIS_UNAVAILABLE", Sev: risk.SEV2, Ticker: o.r.cfg.Ticker,
			Text: fmt.Sprintf("the durable our_fill history could not be read "+
				"(%v), so H-HALT-5's ledger starts from this adoption alone; any "+
				"position older than it has no cost basis and the trigger will "+
				"refuse to evaluate rather than value it at the mark", err),
		})
	}
	for _, row := range rows {
		if f, ok := o.fillFromRow(row); ok {
			o.applyPnLFill(f)
		}
	}

	events, err := lifecycle.ConvertFills(adopted)
	if err != nil {
		// Unreachable for the reason `recordBackfilled` gives -- §7.5 converted
		// this same slice and refused to produce an Adoption when it could not --
		// and reported anyway, because this is the one call that sets the
		// ledger's opening balance and a silent `_ = err` here is a loss floor
		// measured from the wrong zero.
		o.r.anom.raise(risk.Anomaly{
			Class: "PNL_BASIS_UNAVAILABLE", Sev: risk.SEV2, Ticker: o.r.cfg.Ticker,
			Text: fmt.Sprintf("the adoption's %d owned fill(s) did not convert "+
				"(%v), so none of the history this process inherited reaches "+
				"H-HALT-5's ledger", len(adopted), err),
		})
		return
	}
	for _, f := range events {
		o.applyPnLFill(f)
	}
}

// fillFromRow reads one durable `our_fill` row back into the ledger's own form.
//
// A row whose side does not parse is REFUSED rather than guessed. The side
// decides the sign of both the position and the cash (H-CO-1), so a guess is a
// fabricated basis; refusing leaves the ledger's quantity disagreeing with the
// authoritative one, which is exactly the `PNL_BASIS_UNAVAILABLE` refusal
// H-HALT-5 already defines. Failing into an existing not-fired path is better
// than inventing a number that the loss floor is then compared against.
func (o *owner) fillFromRow(row hstore.FillRow) (risk.FillEvent, bool) {
	var side quote.Side
	switch row.Side {
	case quote.SideYes.String():
		side = quote.SideYes
	case quote.SideNo.String():
		side = quote.SideNo
	default:
		o.r.anom.raise(risk.Anomaly{
			Class: "PNL_BASIS_UNAVAILABLE", Sev: risk.SEV2, Ticker: row.Ticker,
			Text: fmt.Sprintf("our_fill row %s carries side %q, which is neither "+
				"%q nor %q; the side decides the sign of the position and of the "+
				"cash, so the row is refused rather than guessed and this "+
				"market's P&L will not evaluate", row.TradeID, row.Side,
				quote.SideYes, quote.SideNo),
		})
		return risk.FillEvent{}, false
	}
	return risk.FillEvent{
		TradeID:      row.TradeID,
		OrderID:      row.OrderID,
		Ticker:       row.Ticker,
		Side:         side,
		Price4:       row.Price4,
		Count:        row.Count,
		Fee:          row.Fee,
		IsTaker:      row.IsTaker,
		ExchangeTsMs: row.ExchangeTsMs,
	}, true
}

// applyPnLFill offers one fill to the ledger and remembers the market it was in.
//
// The market is recorded only when the fill was NEW, because a duplicate means
// the market was recorded when the first copy landed. What the set is for is
// `evaluatePnL` asking about every market the ledger holds -- see `pnlTickers`.
func (o *owner) applyPnLFill(f risk.FillEvent) {
	if o.pnl.Apply(f) {
		o.pnlTickers[f.Ticker] = struct{}{}
	}
}

// applyEvent folds one websocket event into the gate and the book.
//
// `core.Rig.Handle` is reached ONLY through `Gate.ApplyFrame`, and never called
// directly. The gate owns delivery: it decides whether a frame reaches the book
// at all (a granularity frame or an undeliverable one does not), it quarantines
// the book when the handler refuses, and `FrameEffects.Delivered` is its REPORT
// of what it did rather than permission for the caller to do it afterwards.
func (o *owner) applyEvent(ev wsx.Event, tokens chan<- wsx.ReconcileToken) {
	if o.r.qual != nil && ev.Kind != wsx.EventFrame {
		name := "websocket:" + ev.Kind.String()
		if err := o.r.qual.RecordEvent("state", name, time.Now().UTC()); err != nil {
			o.r.failQualification(fmt.Errorf("recording websocket state: %w", err))
		}
	}
	switch ev.Kind {
	case wsx.EventConnected:
		o.bookSID = 0
		eff := o.r.gate.OnConnect(ev.At)
		o.r.anom.raiseAll(eff.Anomalies)
		o.restReducer.Invalidate()
		o.f5ResnapshotPending = false
		// A new generation invalidates every read taken under the old one, and
		// the token is what says so. Delivering it triggers an IMMEDIATE poll,
		// which is H-ORD-5's reconciliation and is what unlocks placement.
		o.offerToken(tokens, eff.Token)
		// subscribeDelta already causes the exchange's initial snapshot. There
		// is no SID to address until its acknowledgement or snapshot arrives.

	case wsx.EventDisconnected:
		o.bookSID = 0
		eff := o.r.gate.ApplyDisconnect(ev.At, ev.Clean)
		o.restReducer.Invalidate()
		o.f5ResnapshotPending = false
		o.r.anom.raiseAll(eff.Anomalies)
		if eff.ResetBooks {
			// Every level carried across the gap may already be wrong, and a
			// trade arriving before the replacement snapshot would be
			// attributed to it. `core` discards five pieces of state together
			// and dropping any one of them fails silently, which is why this is
			// its call and not a field-by-field reset here.
			o.r.book.ResetOnReconnect()
		}
		// The token is offered on DISCONNECT as well as on connect. The poller's
		// own contract says why: "on disconnect it is the first reading of an
		// account nobody is watching over the socket any more."
		o.offerToken(tokens, eff.Token)

	case wsx.EventDisconnectReduce:
		// F4. `lip-0qj` is exactly this relay: the supervisor observes the
		// outage crossing `disconnect_reduce_s` and the gate is what turns it
		// into a REDUCING market. Nothing else forwards it.
		eff := o.r.gate.NoteDisconnectSustained(ev.Down, ev.At)
		o.r.anom.raiseAll(eff.Anomalies)
		o.noteReduce(eff.Reduce)
		o.resnapshot(eff.Resnapshot)

	case wsx.EventFrame:
		info := wsx.InspectFrame(ev.Frame)
		frame := ev.Frame
		eff := o.r.gate.ApplyFrame(info, func() error {
			return o.r.book.Handle(frame)
		}, ev.At)
		o.r.anom.raiseAll(eff.Anomalies)
		o.noteReduce(eff.Reduce)
		if info.BookSubscribeSID != nil {
			o.bookSID = *info.BookSubscribeSID
		} else if o.bookSID == 0 && info.Kind == wsx.FrameSnapshot && eff.Delivered &&
			info.Ticker == o.r.cfg.Ticker && info.SID != nil && *info.SID > 0 &&
			o.r.gate.BookCurrent(info.Ticker) {
			o.bookSID = *info.SID
		}
		o.retryF5Resnapshot()
		// `core.Rig` detects its own subscription-wide sequence gaps and asks
		// for a resnapshot through `NeedsResnapshot`; the gate asks separately
		// through `FrameEffects`. Both are honoured, and the gate is told about
		// core's gap so the two do not disagree about whether the book is
		// trustworthy.
		if o.r.book.NeedsResnapshot {
			o.r.book.NeedsResnapshot = false
			gapEff := o.r.gate.NoteSeqGap(ev.At)
			o.r.anom.raiseAll(gapEff.Anomalies)
			o.noteReduce(gapEff.Reduce)
			o.resnapshot(true)
		}
		o.resnapshot(eff.Resnapshot)
		// H-Q-4a's episode, folded from the OUTCOME of this frame and taken
		// LAST -- after `NoteSeqGap` has had its chance to quarantine every
		// book. A delivered delta that arrived in the same read as a
		// subscription-wide gap is a delta onto a book the gate has just
		// stopped trusting, and clearing an episode from it would be certifying
		// depth nothing has re-established.
		o.noteBookGate(info, eff.Delivered, ev.At)
		o.expireRESTIfRecovered()
	}
}

// noteBookGate advances H-Q-4a's continuous gate-failure episode, and it is the
// ONLY thing that writes to it.
//
// The rule is stated as a conjunction because every clause is load-bearing:
//
//   - `delivered` is `wsx.FrameEffects.Delivered`, which is "ApplyFrame invoked
//     the handler AND the handler returned nil". A frame core REFUSED left the
//     book exactly as it was, so it is evidence about the feed and none at all
//     about depth. Neither starting nor clearing an episode from one is right,
//     and clearing is the one that costs money: a market whose every frame is
//     malformed would look permanently recovered.
//   - A BOOK frame. A trade print says nothing about resting depth, and the
//     unfiltered `trade` subscription delivers the whole exchange tape, so
//     judging the qualifying walk on one would re-evaluate this market from
//     somebody else's fill.
//   - `BookCurrent`, which is connected, unquarantined and snapshotted on THIS
//     generation. A delta cannot reopen a quarantined or unsnapshotted
//     generation -- it is an increment against a book we have decided not to
//     trust -- while an accepted delta against a book this connection DID
//     snapshot can perfectly well recover it, which is why the test is on the
//     resulting book rather than on the frame kind.
//
// What is deliberately absent is any other event. A disconnect, a reconnect, a
// generation change, a portfolio walk, a rejected frame and a clock step all
// leave the episode exactly as they found it: H-Q-4a's interval is CONTINUOUS
// FAILURE OF THE BOOK, and an episode that reset on a reconnect would give a
// market that flapped every 25 seconds an adding quote that never came off.
func (o *owner) noteBookGate(info wsx.FrameInfo, delivered bool, at wsx.Stamp) {
	if !delivered || info.Ticker != o.r.cfg.Ticker {
		return
	}
	if info.Kind != wsx.FrameSnapshot && info.Kind != wsx.FrameDelta {
		return
	}
	if !o.r.gate.BookCurrent(info.Ticker) {
		return
	}
	book := o.r.book.Book(info.Ticker)
	if book == nil {
		// Delivered, current, and core holds no book for it. There is nothing to
		// judge, so nothing is judged: this is the fail-closed reading, because
		// the alternative -- treating "no book" as a failing walk -- would start
		// an episode from an absence rather than from a measured thin market.
		return
	}

	// H-Q-4's own words: "if the market's own qualifying walk fails on either
	// side (core.Book.Qualifies() == 0), the snapshot is excluded for everyone
	// and our presence earns nothing".
	if book.Qualifies() != 0 {
		// A fresh, complete, qualifying book. H-Q-4a's re-entry condition, and
		// the ONLY thing that clears the episode. The next failure gets a whole
		// new `gate_fail_debounce_s`, which is what "continuous" means.
		delete(o.gateFailSince, info.Ticker)
		delete(o.gateFailPinged, info.Ticker)
		return
	}
	if _, open := o.gateFailSince[info.Ticker]; open {
		// Continues. The start is NOT moved -- see `gateFailSince`.
		return
	}
	o.gateFailSince[info.Ticker] = at.Mono
}

// gateFailFor is how long this market's continuous gate failure has run, and
// whether one is running at all.
//
// `now` is the caller's monotonic reading and this function reads no clock, for
// the same reason `wsx.Gate` reads none: one clock, injected, so a test can
// drive thirty seconds in one call and a scenario can replay it exactly.
func (o *owner) gateFailFor(now time.Duration, ticker string) (time.Duration, bool) {
	since, open := o.gateFailSince[ticker]
	if !open {
		return 0, false
	}
	return now - since, true
}

// gateFailStopped is H-Q-4a's threshold: the market has been failing its
// qualifying walk continuously for `gate_fail_debounce_s`.
//
// The comparison is `>=` and the boundary belongs to the STOPPED side. §16
// states the parameter as a duration of continuous failure and H-Q-4a as
// "after gate_fail_debounce_s of continuous gate failure", so a market that has
// been failing for exactly the debounce has satisfied it. A `>` here is not a
// rounding preference: the owner re-evaluates on a tick and on every event, so
// with a strictly-greater test the response waits for whatever wakes the loop
// NEXT -- up to `ownerTick` in a market that has gone quiet, and in a replay
// against a frozen clock, forever.
func (o *owner) gateFailStopped(now time.Duration, ticker string) bool {
	d, open := o.gateFailFor(now, ticker)
	return open && d >= o.p.GateFailDebounce
}

// gateFailQuiet is the DEBOUNCE ITSELF: an episode is open and has not yet run
// its `gate_fail_debounce_s`.
//
// H-Q-4 forbids placing into a non-qualifying book from the first frame -- "our
// presence earns nothing. Do not place." -- and HR-012 is explicit that the
// debounce protects against CHURN on transient blips and nothing else. So this
// window is one-sided: no new quote-derived write of either kind, and no cancel
// either. What is already resting stays exactly where it is, which is what makes
// a book that recovers in two seconds cost nothing at all.
func (o *owner) gateFailQuiet(now time.Duration, ticker string) bool {
	d, open := o.gateFailFor(now, ticker)
	return open && d < o.p.GateFailDebounce
}

// gateFailBlocksPlacement is §6.6's re-evaluation of a QUEUED placement against
// the episode.
//
// It is not the same test as the one `evaluate` applies, and the difference is
// the whole reason it exists: `evaluate` decides whether to enqueue anything
// NEW, while this decides whether an intent enqueued from a book that qualified
// may still leave the process. §6.6 holds intents re-evaluated at dequeue
// precisely so that a decision taken against conditions that have since changed
// is dropped rather than sent, and "the book stopped qualifying while this sat
// in the queue" is exactly that.
//
// Past the debounce the block narrows to the ADDING side. H-Q-4a keeps the
// aggregate-capped reducer (H-Q-5a, H-Q-5b) and §5.2's REDUCING row is what
// rests it, so a reducing-side placement is the EXIT and must still be able to
// go out -- I1: every stop path here stops adding risk, none of them stops
// reducing it.
func (o *owner) gateFailBlocksPlacement(now time.Duration, in quote.Intent) bool {
	if o.gateFailQuiet(now, in.Market) {
		return true
	}
	return o.gateFailStopped(now, in.Market) && in.Role == quote.RoleAdding
}

// offerToken retains the newest generation when the poller's channel is full.
// A disconnect token already queued must never strand a later reconnect.
func (o *owner) offerToken(tokens chan<- wsx.ReconcileToken, tok wsx.ReconcileToken) {
	if !tok.Valid() {
		return
	}
	o.reconcileToken, o.reconcileOut = tok, tokens
	o.reconcilePending = true
	o.retryReconcile()
}

func (o *owner) retryReconcile() {
	if !o.reconcilePending || o.reconcileOut == nil {
		return
	}
	select {
	case o.reconcileOut <- o.reconcileToken:
		o.reconcilePending = false
	default:
	}
}

// observeSleep relays F7 from the owner's actual iteration into the live
// socket, poller and audit stream. The two inputs stay separate integers:
// time.Time.Sub would silently use its embedded monotonic reading for both.
func (o *owner) observeSleep(wallMs int64, mono time.Duration,
	tokens chan<- wsx.ReconcileToken) {
	eff := o.sleep.Observe(wallMs, mono)
	if !eff.Detected {
		return
	}

	if eff.Resnapshot {
		// A sleep invalidates the accepted book before evaluate can place from
		// it. NoteSeqGap supplies the existing quarantine until a full snapshot
		// lands; its BOOK_SEQ_GAP anomaly would misidentify this cause, so F7's
		// own anomaly below is the durable explanation.
		o.reconcileToken = o.r.gate.ObservationGap(o.r.ex.Clock.Now())
		o.resnapshot(true)
	}
	if eff.ReconcileNow {
		// The poller treats every token receipt as an immediate complete walk,
		// including a repeat token on the current connection generation.
		o.offerToken(tokens, o.reconcileToken)
	}

	o.sleepDowntime += eff.Downtime
	for _, a := range eff.Anomalies {
		a.Ticker = o.r.cfg.Ticker
		if eff.Downtime > 0 {
			// `uptime` is deferred from the pilot's five-table store. Keep a
			// compact durable interval in its existing anomaly journal so the
			// unobserved time is not silently counted as healthy uptime.
			a.Text += fmt.Sprintf("; uptime downtime interval wall_ms=[%d,%d] "+
				"duration=%s cumulative=%s",
				wallMs-int64(eff.Downtime/time.Millisecond), wallMs,
				eff.Downtime, o.sleepDowntime)
		}
		o.r.anom.raise(a)
	}
}

// resnapshot asks the supervisor, the socket's sole writer, to send the
// existing subscription a fresh snapshot request. A full channel is retried.
func (o *owner) resnapshot(want bool) {
	if want {
		o.requestF5Resnapshot()
	}
}

// scheduleLoop reads §9's schedule on `schedule_poll_s`, forever.
//
// It polls IMMEDIATELY on entry and then on the interval. The first read is the
// one that lets the market quote at all -- until it lands there is no close to
// enforce a lead against -- so waiting a full interval for it would mean every
// start of this process spends `schedule_poll_s` stopped for a reason that has
// nothing to do with the market.
//
// A failed read is not retried faster and is not escalated here. The owner owns
// that judgement: it holds the previous reading, it knows how old it is, and
// `scheduleStale` is where a reading stops being usable. A poller that decided
// on its own that a schedule was too old would be a second opinion about the
// same fact.
func (r *rig) scheduleLoop(ctx context.Context, out chan<- rest.ScheduleResult) {
	t := time.NewTicker(r.cfg.Params.SchedulePoll)
	defer t.Stop()
	var backoff readBackoff

	for {
		res := backoff.schedule(ctx, r.api, r.cfg.Ticker, r.ex.Mono)
		var throttle *rest.RateLimitError
		if errors.As(res.Err, &throttle) {
			// Every throttle observation must reach the shared rate controller.
			select {
			case out <- res:
			case <-ctx.Done():
				return
			}
		} else {
			select {
			case out <- res:
			case <-ctx.Done():
				return
			default:
				// The owner has not taken the previous one. Drop THIS one rather
				// than blocking: the reads are replacements, so the owner is about
				// to consume an answer at most one interval older than this, and a
				// poller parked on a send is a poller that has stopped observing.
			}
		}
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
	}
}

// applySchedule folds one complete schedule read into the owner.
//
// A read that did not land changes NOTHING -- not the close, not the flags, not
// the freshness clock. That last one is the important part: refreshing the clock
// on a failed read would report the schedule current while holding an answer
// nobody re-established, which is precisely the shape `wsx.applyFills` refuses
// for the same reason ("the walk itself completed, but no fill in it could be
// attributed, and reporting the endpoint current on that basis leaves A13
// authorising placement from a read we could not interpret").
func (o *owner) applySchedule(res rest.ScheduleResult) {
	o.noteRESTError(res.Err)
	o.r.anom.raiseAll(res.Anomalies)
	if !res.Observed() {
		return
	}

	if res.TradingClosed && !o.tradingClosed {
		// H-CLOSE-4, OBSERVED. This is the one close the arithmetic cannot see
		// coming, and until this read existed nothing in this binary could
		// produce the flag at all.
		o.r.anom.raise(risk.Anomaly{
			Class: "TRADING_CLOSED", Sev: risk.SEV2, Ticker: o.r.cfg.Ticker,
			Text: fmt.Sprintf("%s reports status %q: trading has stopped. This "+
				"is the close OBSERVED rather than computed, which is the only "+
				"way a can_close_early market's close is ever seen (H-CLOSE-4)",
				o.r.cfg.Ticker, res.Status),
		})
	}

	o.closeAt, o.hasClose = res.CloseTime, res.HasClose
	o.canCloseEarly = res.CanCloseEarly
	o.tradingClosed = res.TradingClosed
	o.scheduleRead = o.r.ex.Mono()
	o.scheduleEver = true
}

// untilClose is `close_time - now`, and whether we know it at all.
//
// The second result is `quote.MarketInput.HasClose` and it is not a
// convenience. An unread schedule is NOT a close far away: §5.2 treats an
// unknown close as a lead that cannot be enforced and escalates, whereas a
// zero `time.Time` differenced against now is a close roughly two thousand
// years in the past, which reads as "settle immediately".
func (o *owner) untilClose() (time.Duration, bool) {
	if !o.hasClose || o.scheduleStale() {
		return 0, false
	}
	return o.closeAt.Sub(time.UnixMilli(o.r.ex.NowMs())), true
}

// scheduleStale is H-CLOSE-0 stated as an expiry on the reading itself.
//
// A close_time we read once and have not refreshed is not a fact about the
// market, it is a fact about the market AS OF THEN -- and §9 is explicit that
// "neither is assumed static". HR-017 is that difference costing a close:
//
//	at schedule_poll_s = 300 with final_lead = 60s, a close_time that moves
//	from 17:00 to 12:03 at 12:00:01 is next observed at 12:05 -- after the
//	close. Neither the close lead nor the final cancel ever ran.
//
// The threshold is not a taste. H-CLOSE-0's rule is "a lead cannot be enforced
// unless the schedule is read at least twice within it", which `cfg.Validate`
// already enforces on the CONFIGURATION by refusing `schedule_poll_s * 2 >
// final_lead`. The same rule applied to a READING says a sample older than
// `final_lead` cannot enforce `final_lead`, whatever value it carries. So past
// that age the schedule stops being usable and `HasClose` goes false -- which
// stops the adding side through `closeUnknown` and leaves the exit alive.
//
// This is the direction that matters. An ABSENT schedule is conspicuous; a
// STALE one looks exactly like a good one, and every lead computed from it
// reads as enforced.
func (o *owner) scheduleStale() bool {
	if !o.scheduleEver {
		return true
	}
	return o.r.ex.Mono()-o.scheduleRead > o.p.FinalLead
}

// untilCloseOrZero adapts `untilClose` to `PastFinalLead`'s argument pair.
//
// `PastFinalLead(untilClose, hasClose, p)` returns false when `hasClose` is
// false, which is the correct reading: a market whose close we have not read is
// not past its final lead, it is a market whose lead cannot be enforced -- and
// §5.2 escalates that separately rather than acting on it here.
func (o *owner) untilCloseOrZero() (time.Duration, bool, cfg.Params) {
	u, has := o.untilClose()
	return u, has, o.p
}

// closeUnknown stops the market while §9's schedule has not been read.
//
// H-CLOSE-0 hands this case to the caller rather than resolving it: "a market
// whose close_time we do not know is one we cannot enforce a lead on, and
// H-CLOSE-0 makes that the caller's problem to escalate rather than this
// function's to assume away." This is the caller, and stopping is what
// escalating means here.
//
// It stops ADDING and nothing else -- §5.2's response to a market-scoped stop
// is REDUCING, so the exit stays alive and the position stays managed. The
// alternative, quoting on, means resting a new adding order into a market that
// may close before the next poll, with no lead having been enforced and no
// H-CLOSE-3 final cancel having run. HR-017 is that failure with a slow poll;
// this is the same failure with no poll at all.
//
// It is normal for a few seconds at startup, before the first schedule read
// lands, so it is reported only once it has persisted past the interval that
// was supposed to refresh it.
func (o *owner) closeUnknown(hasClose bool) bool {
	if hasClose {
		// The schedule is current again. Re-arm, so a second outage is reported
		// as loudly as the first -- a once-per-process alert about a recurring
		// condition is an alert that describes the first hour of a deployment
		// and nothing after it.
		o.schedulePinged = false
		return false
	}
	if !o.schedulePinged {
		o.schedulePinged = true
		age, known := o.scheduleAge()
		o.r.anom.raise(risk.Anomaly{
			Class: "SCHEDULE_UNUSABLE", Sev: risk.SEV1, Ticker: o.r.cfg.Ticker,
			Text: fmt.Sprintf("%s has no usable close_time (%s). No close lead "+
				"can be enforced from a schedule this process does not hold, "+
				"and H-CLOSE-3's final cancel cannot run either, so the market "+
				"is STOPPED: the adding side comes off and is confirmed absent, "+
				"and the capped reducer stays (§5.2, A8, I1). §9 reads it from "+
				"/markets/{ticker} every schedule_poll_s %v",
				o.r.cfg.Ticker, scheduleWhy(age, known, o.p.FinalLead),
				o.p.SchedulePoll),
		})
	}
	return true
}

// scheduleAge is how long since a complete schedule read, if there has been one.
func (o *owner) scheduleAge() (time.Duration, bool) {
	if !o.scheduleEver {
		return 0, false
	}
	return o.r.ex.Mono() - o.scheduleRead, true
}

// scheduleWhy distinguishes the two ways a schedule is unusable, because they
// want different responses from an operator: one is an endpoint that has never
// answered, the other is one that has stopped.
func scheduleWhy(age time.Duration, known bool, bound time.Duration) string {
	if !known {
		return "no schedule read has ever completed"
	}
	return fmt.Sprintf("the last complete read was %v ago, past final_lead %v "+
		"-- H-CLOSE-0 requires the schedule be sampled at least twice within "+
		"the lead it enforces, so a reading older than the lead cannot enforce "+
		"it whatever value it carries (HR-017)",
		age.Truncate(time.Second), bound)
}

// earlyCloseDue is the operator's H-CLOSE-4 rule, and it is the one deviation
// in this file from §16's numbers.
//
// §16's `close_lead` is 1h, cut from 4h by HR-011 to bound how long a resting
// reducer faces a stale book. That trade is made against a close we can see
// coming. `can_close_early` markets are the ones we cannot: they settle on
// external information at a moment no schedule predicts, and 192 of the 200
// active LIP programmes carry the flag -- so this is the ordinary case, not the
// exception, and "prefer against selecting them" (H-CLOSE-4) does not scale to
// a universe that is 96% early-closeable.
//
// The operator's decision is therefore to stop ADDING four hours out in those
// markets rather than one. It is expressed as a market-scoped `Stop` and not as
// a modified `close_lead`, and the difference matters in three ways:
//
//   - §5.2's response to a stop is REDUCING -- "adding side cancelled,
//     confirmed absent; capped reducer rests" -- which is exactly the intent.
//     `MarketInput.Stop` is explicit that a stop "sends the market to REDUCING,
//     never to a state that cancels everything, which is the inversion the
//     whole design turns on." The EXIT stays alive. Nothing here cancels it.
//   - `close_lead` and `final_lead` are untouched, so SETTLING still begins at
//     `close_time - close_lead` and H-CLOSE-3's final cancel still runs at
//     `final_lead`. This composes with §9 rather than replacing it.
//   - §16 stays the table the `run` row records verbatim. A per-deployment
//     backoff in `cfg.Params` would be a spec deviation dressed as
//     configuration, which `params_test.go` exists to refuse.
//
// It returns false when the close is unknown. That is not an oversight: an
// unread schedule already produces `HasClose = false`, which §5.2 escalates on
// its own, and manufacturing a stop from a number we do not have would silence
// that escalation with an answer.
func (o *owner) earlyCloseDue(untilClose time.Duration, hasClose bool) bool {
	if !hasClose || !o.canCloseEarly || o.r.cfg.EarlyCloseLead <= 0 {
		return false
	}
	return untilClose <= o.r.cfg.EarlyCloseLead
}

func (o *owner) noteReduce(tickers []string) {
	for _, t := range tickers {
		if t == o.r.cfg.Ticker {
			o.reduceNoted = true
		}
	}
}

// applyRead folds one poll cycle into the gate and the position model.
//
// The argument order is `wsx`'s and must not be rearranged: orders, then fills,
// then positions. Orders first so an unresolved reservation is bound before this
// same cycle's fills are classified against the ledger; positions LAST because
// they overwrite (H-POS-1), and applying them first double-counts every fill
// that landed inside the cycle.
func (o *owner) applyRead(read wsx.PortfolioRead) {
	for _, throttle := range read.RateLimits() {
		o.noteRESTThrottle(throttle)
	}
	now := o.r.ex.Mono()
	eff := wsx.ApplyPortfolio(o.r.gate, o.r.pf, o.r.store.Ownership(), o.r.store,
		read, risk.Live, now, o.p)
	if o.r.qual != nil {
		complete := eff.Applied[wsx.TruthFills] &&
			eff.Applied[wsx.TruthOrders] && eff.Applied[wsx.TruthPositions]
		if err := o.r.qual.RecordPortfolioWalk(!eff.Stale, complete,
			time.Now().UTC()); err != nil {
			o.r.failQualification(fmt.Errorf("recording portfolio walk: %w", err))
		}
	}

	o.r.anom.raiseAll(eff.Anomalies)
	o.noteReduce(eff.Reduce)
	o.stopForForeignOrders(eff.Foreign)
	o.expireRESTIfRecovered()

	for _, f := range eff.OwnedFill {
		if _, err := o.r.store.RecordFill(o.r.run, f, o.r.ex.NowMs(), false); err != nil {
			o.r.anom.raise(risk.Anomaly{
				Class: "FILL_NOT_RECORDED", Sev: risk.SEV1, Ticker: f.Ticker,
				Text: fmt.Sprintf("our fill %s on order %s could not be "+
					"submitted to the store (%v); H-ORD-6 makes trade_id the "+
					"join against rig.db, and a fill that is not recorded is "+
					"one no later analysis can find", f.TradeID, f.OrderID, err),
			})
		}
	}
	// The same rows, with the opposite provenance. These are fills that were
	// already on the account when this process started but sit OUTSIDE
	// `backfill_h`, so §7.5's walk never asked for them and `recordBackfilled`
	// never wrote them -- this poll is genuinely their first observation, and
	// H-ORD-6's first-observer-wins makes whatever label it writes the row's
	// label forever. `true` is that label: they are history we INFERRED from a
	// walk over the past, not trading we watched happen, and an analysis joining
	// `our_fill` against `rig.db` that cannot tell them apart reads every
	// restart as a burst of activity (`lip-da6`).
	for _, f := range eff.BackfilledFill {
		if _, err := o.r.store.RecordFill(o.r.run, f, o.r.ex.NowMs(), true); err != nil {
			o.r.anom.raise(risk.Anomaly{
				Class: "FILL_NOT_RECORDED", Sev: risk.SEV1, Ticker: f.Ticker,
				Text: fmt.Sprintf("the inherited fill %s on order %s could not "+
					"be submitted to the store (%v); it is history older than "+
					"backfill_h that only the live walk ever reports, so this "+
					"row is lost rather than late", f.TradeID, f.OrderID, err),
			})
		}
	}
	// H-HALT-5's ledger, advanced from the SAME effects the two loops above just
	// wrote rows from, and from both provenances. A fill older than `backfill_h`
	// was still paid for and still moved the position, so a ledger taking only
	// `OwnedFill` would price inherited inventory against a basis it never saw --
	// and, because the quantity check would then fail, would refuse to evaluate
	// the loss floor for as long as that inventory was held.
	for _, f := range eff.OwnedFill {
		o.applyPnLFill(f)
	}
	for _, f := range eff.BackfilledFill {
		o.applyPnLFill(f)
	}
	// The authoritative position, from a COMPLETE walk and from nothing else.
	// `Applied` is `wsx`'s report that this walk replaced rather than went stale,
	// and an incomplete one leaves the previous figure standing: H-PAGE-1's
	// "stale, never empty", applied to the figure the ledger is checked against.
	//
	// Every record is kept, including the flat ones. A market that has traded to
	// flat still carries realised cash, and dropping it here would drop that cash
	// from the total -- while also making it a market the ledger knows and the
	// caller did not ask about, which `Evaluate` refuses on.
	if eff.Applied[wsx.TruthPositions] {
		o.recordPositionDisagreements(eff.Records)
		o.pnlQExch = make(map[string]num.Qty, len(eff.Records))
		for _, rec := range eff.Records {
			o.pnlQExch[rec.Ticker] = rec.QExch
		}
		o.inventoryStuck.observe(now, o.r.gate.Generation(), o.pnlQExch, o.p.InvHard)
		o.pnlQKnown = true
	}
	o.stopForPortfolio(eff)
	// F17, and it sits in the ONLY place it can: below `eff.Stop` and above the
	// canary, because `commitStop` is first-writer-wins and this is a ranking of
	// causes rather than a sequence of steps.
	//
	// Below `eff.Stop`, because the causes funnelled through there include a
	// hard position drift -- and "our model of our own inventory is wrong" is a
	// worse thing to be woken for than "our inventory is too large". The two are
	// simultaneously true of a position that appears out of nowhere past
	// `inv_kill`, and the operator reading the latch at 3am is better served by
	// the one that says the model cannot be trusted. Nothing is lost by losing
	// the race: the harness is stopped either way, and the SEV1
	// `INVENTORY_KILL` anomaly is raised whichever cause takes the latch.
	//
	// Above the canary, because `inv_kill` is a row of the §12 halt table and
	// "the canary traded" is a rung policy. That ordering is the one this file
	// already applies to every other pair of causes here.
	if eff.InvKill != "" {
		o.requestStop("inv_kill", eff.InvKill)
	}

	// H-HALT-5, and it is evaluated HERE as well as on the tick because this is
	// the moment both of its inputs change: the new owned fills are in the ledger
	// and the latest complete authoritative position is installed, both a few
	// lines above.
	//
	// The RANKING is the reason it sits between those two blocks, and it is a
	// ranking of causes rather than a sequence of steps -- `commitStop` is
	// first-writer-wins, so position in this list decides which cause the durable
	// latch carries and therefore which row the §10.4 operator reads at 3am.
	//
	// Below `inv_kill`, because "we hold more than we said we would" is a fact
	// about the position while "we have lost more than we said we would" is a
	// CALCULATION over it -- one that depends on a mark, which may itself be the
	// thing that is wrong. When both fire on the same read the operator is better
	// served by the measurement than by the arithmetic over it.
	//
	// Above the canary, for the reason `inv_kill` is above it: `pnl_kill` is a row
	// of the §12 halt table and "the canary traded" is a rung policy. Nothing is
	// lost by losing either race -- the harness stops either way and the SEV1
	// `PNL_KILL` anomaly is raised whichever cause takes the latch.
	o.evaluatePnL()

	// §7.9's canary bound, and it comes AFTER `eff.Stop` on purpose. A taker
	// fill, a foreign fill and a hard position drift all arrive on this same
	// cycle's effects and all of them are stronger reasons to be stopped than
	// "the canary traded"; `commitStop` is first-writer-wins, so the order of
	// these two blocks is what decides which reason the latch carries.
	//
	// BOTH slices are offered, and inherited history is filtered out by the
	// RULE rather than before it. `lip-da6` routes a baseline trade id into
	// `BackfilledFill`, so passing only `OwnedFill` would already be correct --
	// and it would make this decision depend entirely on that routing being
	// right, with nothing here able to disagree. `liveOwnedFill` reaches its
	// answer from the trade id, which is the fact §7.9 is actually about; a
	// fill the canary never sees is a fill the canary cannot be wrong about,
	// and `M-2T6-NOBASELINE` proves the rule is still doing the work.
	for _, f := range append(append([]risk.FillEvent{}, eff.OwnedFill...),
		eff.BackfilledFill...) {

		if o.liveOwnedFill(f) {
			o.canaryStop("canary_owned_fill", f.Ticker)
		}
	}
	// The ENTRY FALLBACK. A position record is not proof of ownership -- the
	// positions endpoint carries no trade identity at all -- so it is here to
	// catch an entry whose fill record we never saw, and nothing else.
	//
	// `QLocal` is the model's figure BEFORE this walk overwrote it, so exactly
	// flat against a nonzero exchange figure is the transition from no position
	// to a position. Only from a COMPLETE walk: H-PAGE-1 makes an incomplete one
	// stale rather than empty, and `Applied` is `wsx`'s report that this one
	// replaced. A record only appears at all when the walk applied, but the test
	// is written against the flag rather than the presence, because "there are
	// records so the walk must have completed" is an inference and this is a
	// safety rule.
	if eff.Applied[wsx.TruthPositions] {
		for _, rec := range eff.Records {
			if rec.QLocal == 0 && rec.QExch != 0 {
				o.canaryStop("canary_position_nonzero", rec.Ticker)
			}
		}
	}

	if eff.Applied[wsx.TruthOrders] &&
		(!o.awaitCancelTruth || read.StartedAt(wsx.TruthOrders).Mono > o.cancelTruthAfter) {
		// A complete orders walk supersedes every earlier cancel sweep. An id
		// listed here is positive evidence of presence and must count again.
		// A walk started before the sweep does not supersede that later proof,
		// even if it happened to finish afterwards.
		clear(o.absentOrders)
		o.noteListedBindings(eff.Bound)
		// A complete orders walk is the ONLY thing that resolves an unknown
		// create, and it resolves it positively: the coid is listed, so the
		// order exists and is now in `Portfolio.LiveOrders`. Absence is not
		// evidence in either direction (H-ORD-2a), so nothing is cleared for
		// not appearing.
		o.clearListed()
		o.clearSwept()
		// A complete orders walk is our model becoming authoritative again, so
		// the sweep-derived shortcut retires with it: whatever this walk lists
		// is in `LiveOrders`, `atRisk` sees it, and the next evaluation decides
		// the side from that rather than from a read taken before it.
		o.cancelConfirmed = [2]bool{}
	}
	// A sweep's verifying orders read contains no position or fill truth. Only
	// an independently applied cycle whose three walks STARTED after that sweep
	// can resolve a possible fill-before-cancel. A pre-sweep in-flight cycle
	// may finish later and must not open the placement gate.
	if o.awaitCancelTruth && eff.Applied[wsx.TruthFills] &&
		eff.Applied[wsx.TruthOrders] && eff.Applied[wsx.TruthPositions] &&
		read.StartedAt(wsx.TruthFills).Mono > o.cancelTruthAfter &&
		read.StartedAt(wsx.TruthOrders).Mono > o.cancelTruthAfter &&
		read.StartedAt(wsx.TruthPositions).Mono > o.cancelTruthAfter {
		o.awaitCancelTruth = false
	}
}

// clearListed drops pending creates the resting-order walk has since listed.
//
// Listing the coid is this path's positive release. A separate completed
// cancel sweep may retire a named ACKed order before it is ever listed; an
// UNKNOWN create without an id cannot use that release. A listed order's
// quantity enters Portfolio.LiveOrders as pending releases, avoiding a double
// count.
func (o *owner) clearListed() {
	if len(o.pending) == 0 {
		return
	}
	for coid, pending := range o.pending {
		if o.hasListedCreate(coid, o.r.cfg.Ticker, pending.side) {
			delete(o.pending, coid)
		}
	}
}

// ---------------------------------------------------------------------------
// H-HALT-5 — the loss floor
// ---------------------------------------------------------------------------

// evaluatePnL is H-HALT-5: value the account's inventory, and halt if the loss
// has reached `pnl_kill`.
//
// It is REFUSAL-FIRST, and that shape is mandated rather than defensive. H-HALT-5
// says that if no mark of acceptable age exists the trigger CANNOT be evaluated:
// SEV2, treated as not-fired, and never as fired-or-safe. So every path that
// cannot produce an honest figure raises and returns, and the one path that
// stops the harness is the one that computed a total from a fresh EXTERNAL mark
// and a complete AUTHORITATIVE position.
//
// What it measures is TRADING P&L and nothing else. No balance can reach
// `risk.TradingPnL` -- there is no method by which one could -- because HR-021's
// finding is that a $100 LIP reward landing mid-drawdown masks it entirely in a
// balance-delta reading. The reward is the thing this system is measuring itself
// against; it is not a component of its P&L.
func (o *owner) evaluatePnL() {
	if o.pnlKilled {
		// Fired once, and the cause is already durable or held for retry by the
		// stop funnel. Re-raising would put a SEV1 into a 256-slot buffer four
		// times a second and re-enter `commitStop` on every tick, for a
		// condition that by construction does not go away.
		return
	}
	if !o.pnlQKnown {
		// No complete positions walk has landed yet, so there is no
		// authoritative figure to check the ledger against -- and checking it
		// against `q_local` instead would compare a fill-derived quantity to one
		// the ACKS also move. Silent, because this is the opening seconds of a
		// run rather than a condition: `Actionable` withholds every placement
		// until all three walks have landed, so nothing has been risked yet.
		return
	}

	in, why := o.pnlInputs()
	res := o.pnl.Evaluate(in)

	// Re-arm every episode that has ENDED, before raising the ones that are
	// live. A market that goes stale, recovers, and goes stale again is two
	// conditions, and an operator told about it only the first time would not
	// know the second happened.
	live := make(map[string]struct{}, len(res.NoMark)+len(res.NoBasis))
	for _, t := range res.NoMark {
		live[pnlEpisode("PNL_MARK_UNAVAILABLE", t)] = struct{}{}
	}
	for _, t := range res.NoBasis {
		live[pnlEpisode("PNL_BASIS_UNAVAILABLE", t)] = struct{}{}
	}
	for k := range o.pnlPinged {
		if _, still := live[k]; !still {
			delete(o.pnlPinged, k)
		}
	}

	for _, t := range res.NoMark {
		reason := why[t]
		if reason == "" {
			reason = "no usable mark exists for this market"
		}
		o.pnlUnavailable("PNL_MARK_UNAVAILABLE", t, reason)
	}
	for _, t := range res.NoBasis {
		o.pnlUnavailable("PNL_BASIS_UNAVAILABLE", t, fmt.Sprintf(
			"the fill-derived position %s disagrees with the authoritative %s, "+
				"so the account holds contracts this ledger has no fills for -- a "+
				"manual trade, a settlement, or a fill we never saw. There is no "+
				"honest basis to value them at, and valuing them AT THE MARK "+
				"would assume they were acquired at today's price, which is the "+
				"assumption most likely to hide a loss. Ignorance is reported, "+
				"not resolved (H-ORD-5a)",
			o.pnl.Qty(t).Wire(), o.pnlQExch[t].Wire()))
	}
	if !res.Evaluable {
		return
	}

	// §12's row reads "P&L <= pnl_kill", so the comparison is INCLUSIVE: exactly
	// the floor fires, and one microdollar above it does not.
	//
	// That is the OPPOSITE sense to `inv_kill`'s strict `>`, and the two are
	// consistent rather than contradictory. `inv_kill` is a level the position
	// may REACH and may not pass -- `Validate` orders it strictly above
	// `inv_hard`, so the band between them belongs to the market-scoped brake.
	// `pnl_kill` has no such neighbour below it: it is a floor, `Validate`
	// refuses a non-negative one because it would fire immediately, and there is
	// no second rule owning the figure itself.
	if res.Total > o.p.PnLKill {
		return
	}
	o.pnlKilled = true
	o.r.anom.raise(risk.Anomaly{
		Class: "PNL_KILL", Sev: risk.SEV1, Ticker: o.r.cfg.Ticker,
		Text: fmt.Sprintf("trading P&L %s has reached pnl_kill %s (§12 reads "+
			"\"P&L <= pnl_kill\", so the floor itself fires). §12 makes this a "+
			"GLOBAL halt: every market stops adding, every reducing quote stays "+
			"live, monitoring continues and the process stays alive (I1). The "+
			"figure is realised cash plus open inventory at the external mid, "+
			"fees included and rewards excluded", res.Total, o.p.PnLKill),
	})
	o.requestStop("pnl_kill", "")
}

// pnlInputs is one evaluation's per-market input: what the exchange says we
// hold, and what the book says it is worth.
//
// It returns the reason a mark could not be formed alongside the inputs, so the
// SEV2 can name WHICH market and WHY without computing the mark a second time.
//
// The market set is the UNION of the last complete walk's and the ledger's. The
// walk's side is obvious; the ledger's is not, and it closes a real hole: a
// market that traded to flat is deleted from `q` and can be absent from a later
// walk's records, while still carrying realised cash that belongs in the total.
// `Evaluate` refuses outright on any ledger market the caller omits, so leaving
// it out would not lose the cash silently -- it would make the trigger
// permanently unevaluable instead.
func (o *owner) pnlInputs() ([]risk.PnLInput, map[string]string) {
	tickers := make([]string, 0, len(o.pnlQExch)+len(o.pnlTickers))
	seen := make(map[string]struct{}, len(o.pnlQExch)+len(o.pnlTickers))
	for t := range o.pnlQExch {
		if _, dup := seen[t]; !dup {
			seen[t] = struct{}{}
			tickers = append(tickers, t)
		}
	}
	for t := range o.pnlTickers {
		if _, dup := seen[t]; !dup {
			seen[t] = struct{}{}
			tickers = append(tickers, t)
		}
	}
	// Deterministic, because the anomaly text names markets in this order and an
	// operator comparing two SEV2s should not have to work out whether a
	// reordering means anything.
	sort.Strings(tickers)

	in := make([]risk.PnLInput, 0, len(tickers))
	why := make(map[string]string)
	for _, t := range tickers {
		// Absence from a COMPLETE walk means flat. That inference is exactly the
		// one `ReplacePositions` makes, and it is only available because the
		// walk completed.
		mk := risk.PnLInput{Ticker: t, QExch: o.pnlQExch[t]}
		if !mk.QExch.IsFlat() {
			// A FLAT market needs no mark: with nothing open there is no
			// unrealised component, so its contribution is realised cash that no
			// price can change. Demanding one anyway would make a wound-down
			// harness -- flat, and the state H-HALT-5 most needs to stay
			// evaluable in -- unevaluable the moment its book went quiet.
			var reason string
			mk.Mark4, mk.MarkOK, reason = o.mark4(t)
			if !mk.MarkOK {
				why[t] = reason
			}
		}
		in = append(in, mk)
	}
	return in, why
}

// mark4 is one market's H-HALT-5 mark: the EXTERNAL mid, YES-denominated, in the
// exchange's own 1e-4 dollar quantum.
//
// The second return says whether it may be used at all, and the third says why
// not. The third exists because H-HALT-5 requires the SEV2 to distinguish a book
// that is ABSENT from one that is merely STALE -- they are the same not-fired
// answer and completely different things to be woken for. Every branch below
// says which of the two it is, in those words.
//
// A mark is only ever available for the CONFIGURED market. This process
// subscribes to one book and there is no second `core.Rig` to ask, so a position
// the account holds in another market cannot be priced here. That does not make
// it worth zero and does not make it skippable: it makes the whole figure
// unevaluable, and names the market. A held position nobody can price is exactly
// the state a loss floor must refuse to guess about.
func (o *owner) mark4(ticker string) (int64, bool, string) {
	if ticker != o.r.cfg.Ticker {
		return 0, false, fmt.Sprintf("%s is not the configured market, so this "+
			"process subscribes to no book for it and no mark exists at any "+
			"age. ABSENT, not stale", ticker)
	}
	// The gate's own mark clock, which is neither of the two 60s clocks. It is
	// stamped only from frames `core` ACCEPTED and retired by a disconnect, a
	// sequence gap or a rejected frame, so it answers "is there a price here we
	// are entitled to believe" rather than "is this market still talking".
	age, state := o.r.gate.PnLMark(ticker, o.r.ex.Clock.Now())
	switch state {
	case wsx.PnLMarkAbsent:
		return 0, false, "no accepted book snapshot exists on the current " +
			"connection: a disconnect, a sequence gap or a rejected frame " +
			"retired the mark and no fresh snapshot has re-established it. " +
			"ABSENT, not stale -- there is no price here of any age"
	case wsx.PnLMarkStale:
		return 0, false, fmt.Sprintf("the last accepted book frame is %v old, "+
			"past pnl_mark_max_age_s %v. STALE, not absent -- a price exists "+
			"and is too old to value inventory against",
			age.Truncate(time.Millisecond), o.p.PnLMarkMaxAge)
	}
	book := o.r.book.Book(ticker)
	if book == nil {
		return 0, false, "the gate holds a fresh mark but no book is installed " +
			"for this market, so there are no levels to take a mid from. " +
			"ABSENT, not stale"
	}
	// Our own possibly-live size on both sides: H-Q-5b's aggregate of RESTING,
	// SENDING, UNKNOWN and unconfirmed-cancel, which is what `restingOn`
	// already returns.
	oursYes, _, _ := o.restingOn(quote.SideYes)
	oursNo, _, _ := o.restingOn(quote.SideNo)
	mark, unavail := quote.ExternalMark4(book.Yes(), book.No(), oursYes, oursNo)
	switch unavail {
	case quote.MarkNoBook:
		return 0, false, "one or both sides of the book carry no levels at all, " +
			"so there is no midpoint to take. ABSENT, not stale"
	case quote.MarkOneSided:
		return 0, false, "one side of the book has no EXTERNAL liquidity once " +
			"our own resting size is subtracted (H-Q-10): the only price there " +
			"is our own, and valuing inventory against our own quote is the " +
			"self-reference that would hold the mark up while the position it " +
			"values got worse. PRESENT and one-sided, not stale"
	}
	return mark, true, ""
}

// pnlEpisode is the dedupe key: one episode is one class on one market.
//
// The classes are kept apart because they are different conditions with
// different fixes -- a stale book is a feed problem and a basis mismatch is an
// accounting one -- and a market can be in both at once.
func pnlEpisode(class, ticker string) string { return class + "\x00" + ticker }

// pnlUnavailable raises one market's SEV2 at most once per unavailable episode.
func (o *owner) pnlUnavailable(class, ticker, why string) {
	key := pnlEpisode(class, ticker)
	if _, pinged := o.pnlPinged[key]; pinged {
		return
	}
	o.pnlPinged[key] = struct{}{}
	o.r.anom.raise(risk.Anomaly{
		Class: class, Sev: risk.SEV2, Ticker: ticker,
		Text: fmt.Sprintf("H-HALT-5 cannot be evaluated while %s: %s. The "+
			"trigger is treated as NOT FIRED, and never as fired-or-safe, so "+
			"the harness keeps running with the loss floor unenforced until "+
			"this clears", ticker, why),
	})
}

// ---------------------------------------------------------------------------
// §12 — harness.stop, the out-of-band halt
// ---------------------------------------------------------------------------

// checkHarnessStop is the operator's stop file: §12's halt that arrives from
// outside the process.
//
// It is a FILE and not a signal because a signal needs a pid. The operator
// reaching for this has a config file and a shell, and `launchd KeepAlive`
// restarts anything they kill -- so the durable thing has to be the instruction,
// not the death of the process. It is the mirror of `live_ok`: one file permits
// the next write, the other stops the harness adding, neither is ever created by
// this binary, and `resolvePaths` refuses a config that aliases them.
//
// It STOPS ADDING AND NOTHING ELSE. §5.1: "DRAINED does not exit the process; it
// idles and keeps monitoring", and `SignalController.Confirm` refuses a drain
// permit to any cause that is not SIGTERM or SIGINT -- its own comment says a
// taker fill "must not be able to buy an exit by being retried through the same
// path", and neither may this. So the reducer stays live, the polls continue,
// the monitor keeps publishing, and the process stays alive holding whatever it
// holds.
//
// `Lstat`, never `Stat`. The question is whether the operator put something at
// that path, and a DANGLING SYMLINK is something: `Stat` follows the link, fails
// to find the target, and reports the path as absent -- which turns a halt the
// operator believes they have requested into silence. Every entry counts:
// regular file, directory, symlink, dangling symlink.
func (o *owner) checkHarnessStop() {
	_, err := os.Lstat(o.r.cfg.Paths.Stop)
	switch {
	case err == nil:
		if o.harnessStopSeen {
			return
		}
		o.harnessStopSeen = true
		o.r.anom.raise(risk.Anomaly{
			Class: "HARNESS_STOP_REQUESTED", Sev: risk.SEV2,
			Text: fmt.Sprintf("%s exists, so §12's out-of-band halt has been "+
				"requested: the harness stops ADDING and nothing else. Every "+
				"reducing quote stays live, the portfolio walks continue, the "+
				"monitor keeps publishing and the process stays alive. Removing "+
				"the file does NOT resume trading -- the stop is durable in the "+
				"halt latch, and §10.4 makes clearing that an operator action",
				o.r.cfg.Paths.Stop),
		})
		o.requestStop("harness_stop", "")

	case errors.Is(err, os.ErrNotExist):
		// Absent, and that is the ordinary answer on every one of the four ticks
		// a second. It is NOT a clear: nothing here ever un-requests a stop.

	default:
		// FAIL CLOSED, and under its own cause. Anything that is not ENOENT --
		// a permission failure, an I/O error, a path whose parent is no longer a
		// directory -- means the control the operator was told to rely on cannot
		// be read. Treating that as absence is the one reading that keeps the
		// harness adding while its stop switch is broken.
		//
		// The cause is DISTINCT from `harness_stop` on purpose. §10.4 has the
		// operator read the latch to learn what happened, and "you asked me to
		// stop" and "I can no longer tell whether you asked me to stop" are
		// different problems with different fixes -- the second one needs the
		// path looked at before the harness is started again.
		if o.harnessStopUnreadable {
			return
		}
		o.harnessStopUnreadable = true
		o.r.anom.raise(risk.Anomaly{
			Class: "HARNESS_STOP_UNREADABLE", Sev: risk.SEV1,
			Text: fmt.Sprintf("%s could not be read (%v), so §12's out-of-band "+
				"halt cannot be evaluated. This is NOT absence: the harness "+
				"stops adding rather than continue with a stop switch it cannot "+
				"see. The path needs looking at before this process is started "+
				"again", o.r.cfg.Paths.Stop, err),
		})
		o.requestStop("harness_stop_unreadable", "")
	}
}

// evaluate is one pass of §5.2, §6.2 and §6.5 over the one market.
func (o *owner) evaluate(now time.Duration) {
	o.retryReconcile()
	o.escalateUnresolved()
	o.checkRuntimeDisk(now)
	o.checkRuntimeStore()
	o.checkFundingHealth()
	// `RetryLatch`, honoured, and FIRST: a held cause that becomes durable on
	// this tick publishes its WINDING_DOWN on this tick, and one that does not
	// keeps `stopHeld` set for the `MarketInput.Stop` term below. Driving it
	// from here rather than from the triggering event is the point -- every
	// caller of `requestStop` is event-driven, and a taker fill does not recur.
	o.retryStop()

	// §5.1's OTHER edges, driven from the tick rather than from a stop.
	//
	// Before lip-xdq `advance` had exactly ONE caller -- the stop funnel -- so
	// the global state moved only on the tick a §12 cause was made durable.
	// WINDING_DOWN -> DRAINED and DRAINED -> WINDING_DOWN are defined in the
	// machine and nothing ever asked for them. So a harness that wound down and
	// reduced to flat never published DRAINED: every snapshot, every §14 report
	// and the whole A9 history said it was still winding down, and `GTInventory`
	// -- the edge that exists because "DRAINED rests no reducer" -- was
	// unreachable in production, because the state it leaves was never entered.
	//
	// It runs BEFORE `NextMarket` below so the market is placed from this tick's
	// global state rather than the last one's.
	//
	// It cannot enable adding, which is what makes it safe to run unconditionally:
	// `GlobalState.AddsRisk` is `g == Running`, and of the edges reachable from
	// the states this loop is ever in, none ends in RUNNING. `Stop` is
	// deliberately false -- the stop funnel is the only thing entitled to assert
	// one, and `Advance` refuses an unlatched `Stop` anyway.
	//
	// `Reconciled` is unread in RUNNING, WINDING_DOWN and DRAINED, which is
	// every state reachable here: `install` seeds the owner from
	// `Startup.State()`, and a Step that returns an Adoption has already been
	// taken to RUNNING or, if latched, to WINDING_DOWN. It is supplied as an
	// honest answer rather than a literal because §5.1's UNKNOWN_RISK rule --
	// "never decays into RUNNING without a complete successful reconciliation"
	// -- is exactly what fresh truth on all three walks attests.
	o.advance(o.globalFacts())

	// The non-gate reduce requests are consumed by THIS evaluation and cleared
	// on the way out, on every exit including the final-cancel one. Anything
	// that must outlive a tick is held by the thing that owns it -- the gate for
	// a disconnect or a book quarantine, `quote.NextMarket`'s own state for
	// inventory and drift -- and never by a second copy here.
	defer func() { o.reduceNoted = false }()

	tick := o.r.gate.Tick(o.r.ex.Clock.Now())
	o.r.anom.raiseAll(tick.Anomalies)
	o.noteReduce(tick.Reduce)
	o.requestCrossChecks(tick.CrossCheck)
	o.retryF5Resnapshot()
	o.expireRESTIfRecovered()
	if tick.Stop {
		o.requestStop("gate", o.r.cfg.Ticker)
	}

	// H-HALT-5 on the tick, which is also H-HALT-5 after every accepted frame:
	// the owner loop runs this function after EVERY event as well as on the
	// 250 ms tick, so a book that has just moved is priced against the position
	// before the next quote is decided from it. A loss floor that only woke on a
	// portfolio poll would be up to `position_poll_s` late on the one input that
	// moves continuously -- the mark.
	//
	// It runs BEFORE `NextMarket` below so that a breach reaches THIS
	// evaluation's `Stop` term rather than the next one's: `requestStop` sets
	// `stopHeld`, and §5.2's REDUCING is what actually takes the adding side off
	// the book.
	o.evaluatePnL()

	// §12's out-of-band halt, checked LAST of the three causes this function can
	// raise. `gate` and `pnl_kill` above are specific automatic findings about
	// the market or the account; this one is the generic fact that somebody
	// touched a file. `commitStop` is first-writer-wins, so checking it here is
	// what keeps a real §12 finding as the cause §10.4 reads when both are true
	// on the same evaluation.
	o.checkHarnessStop()

	ticker := o.r.cfg.Ticker
	if a, ok := o.inventoryStuck.step(ticker, now, o.r.gate.Generation(),
		o.r.gate.TruthAge(wsx.TruthPositions, o.r.ex.Clock.Now()),
		o.p.TruthMaxAge, o.p.Stuck); ok {
		o.r.anom.raise(a)
	}
	q := o.r.pf.Q(ticker)
	untilClose, hasClose := o.untilClose()

	// H-Q-4a, evaluated once and used twice: as a §5.2 stop below, and as the
	// suppression window in the side loop. Reading it from one place is what
	// keeps the two from disagreeing about the boundary instant.
	gateStopped := o.gateFailStopped(now, ticker)
	gateQuiet := o.gateFailQuiet(now, ticker)
	if gateStopped && !o.gateFailPinged[ticker] {
		o.gateFailPinged[ticker] = true
		age, _ := o.gateFailFor(now, ticker)
		o.r.anom.raise(risk.Anomaly{
			Class: "BOOK_GATE_SUSTAINED", Sev: risk.SEV2, Ticker: ticker,
			Text: fmt.Sprintf("this market's own qualifying walk has failed "+
				"continuously for %v, past gate_fail_debounce_s %v; H-Q-4a "+
				"cancels and exchange-confirms every ADDING order and keeps only "+
				"the aggregate-capped reducer. Reward in a gated-out interval is "+
				"zero for every participant, so an order left resting here takes "+
				"directional inventory during an interval that cannot pay -- and "+
				"the gated-out accounting excludes the interval from our uptime "+
				"denominator, so the loss is invisible in the metric (HR-012). "+
				"Re-entry needs a fresh, complete, qualifying book",
				age, o.p.GateFailDebounce),
		})
	}

	next, trig := quote.NextMarket(quote.MarketInput{
		State:  o.market,
		Q:      q,
		Global: o.global,
		// Selected is §10's decision and it is "the only way into QUOTING". The
		// pilot's one market is selected by the operator, so the only question
		// left here is whether this process may add at all -- which is the
		// global state. `Stop` carries every reason the MARKET may not, and
		// §5.2's IDLE -> QUOTING edge already requires `!Stop`, so folding a
		// reduce condition into `Selected` as well would be the same rule
		// applied twice and clearable in only one of the two places.
		Selected: o.global == quote.Running,
		// The gate owns the sticky reduce. `Gate.Reducing` is the latch and the
		// gate is what clears it; `reduceNoted` carries only this evaluation's
		// non-gate requests, principally H-POS-2's drift.
		// The gate owns the sticky reduce; `reduceNoted` carries this
		// evaluation's non-gate requests, principally H-POS-2's drift. The last
		// term is the operator's H-CLOSE-4 backoff -- see `earlyCloseDue`.
		//
		// The FIRST term is `BlockAdding`, honoured. A §12 cause that has
		// been decided and could not be made durable stops adding HERE, which
		// is the one place §5.2 stops it: REDUCING cancels the adding side and
		// keeps the capped exit resting, and a flat market goes to IDLE, whose
		// own guard is what keeps it from resuming. The global state is
		// deliberately NOT moved with it -- publishing WINDING_DOWN on a stop
		// that is not on disk is HR-009 -- so the market stops while the state
		// waits for the latch.
		//
		// It goes through `Stop` and not through `Selected`, because §5.2's
		// IDLE -> QUOTING edge already requires `!Stop`: expressing it in both
		// would be one rule clearable in only one of the two places, and
		// MTDeselected would label the A9 row an operator selection decision
		// rather than a stop.
		//
		// The LAST term is H-Q-4a, and expressing it as a market-scoped stop
		// rather than as a branch of its own is the point. §5.2 answers a stop
		// with REDUCING, which is exactly the response H-Q-4a asks for: the
		// adding side is cancelled and exchange-confirmed absent (A8, H-FAIL-3)
		// and the aggregate-capped reducer keeps resting (H-Q-5a, H-Q-5b). A
		// flat market goes to IDLE and rests nothing, which is the same rule
		// with q == 0 substituted in. §5.2 is explicit that there is "no HALTED
		// per-market state that cancels everything"; a bespoke H-Q-4a branch
		// that cancelled both sides would be that state arriving through a side
		// door, and it would strand the position the reducer exists to exit.
		Stop: o.stopHeld || o.reduceNoted || o.r.gate.Reducing(ticker) ||
			!o.r.gate.Connected() || o.earlyCloseDue(untilClose, hasClose) ||
			o.closeUnknown(hasClose) || gateStopped,
		// A complete active-liquidity walk is the only source of absence.
		ProgramEnded:  o.programMembership.ended,
		UntilClose:    untilClose,
		HasClose:      hasClose,
		TradingClosed: o.tradingClosed,
	}, o.p)
	if next != o.market {
		o.sd.mirrorMarket(ticker, o.market, next, trig)
		o.market = next
	}

	sz := quote.SizesFor(quote.SizeInput{
		State:         o.market,
		Q:             q,
		Funded:        o.f5FundedReducer(q),
		PastFinalLead: quote.PastFinalLead(untilClose, hasClose, o.p),
	}, o.p)

	if sz.FinalCancel {
		// H-CLOSE-3: cancel everything in this market and verify with a sweep.
		// Nothing of ours rests into the close. This is an obligation to ACT and
		// not merely a refusal to place, which is why it is a separate branch
		// from a state that happens to quote nothing.
		o.enqueueCancel(now, quote.SideYes, quote.RoleAdding)
		o.enqueueCancel(now, quote.SideNo, quote.RoleAdding)
		return
	}

	reducing, held := quote.ReducingSide(q)
	actionable := !o.awaitCancelTruth &&
		o.r.gate.Actionable(ticker, o.r.ex.Clock.Now())

	for _, side := range []quote.Side{quote.SideYes, quote.SideNo} {
		role := quote.RoleAdding
		target, wanted := sz.Add, sz.HasAdd
		if held && side == reducing {
			role, target, wanted = quote.RoleReducing, sz.Reduce, sz.HasReduce
		} else if held && side != reducing {
			target, wanted = sz.Add, sz.HasAdd
		}

		if !wanted {
			// The state rests nothing on this side. If something of ours is
			// there, it comes off -- A8 for REDUCING's adding side, and the
			// same act for every other state that quotes nothing.
			//
			// The second term is H-FAIL-3's "off means exchange-confirmed
			// absent" read backwards. `atRisk` is the aggregate the SIZING is
			// evaluated against, and an order the exchange has shown us resting
			// that no complete orders walk has listed yet may be missing from it
			// -- not because the quantity is unknown, but because the order is
			// carried in `pending` under a coid rather than in `LiveOrders`
			// under an id. `sweptOn` asks the other question: has a verifying
			// read SEEN one of ours on this side. Either answer is an obligation
			// to cancel, and only exchange-confirmed absence ends it.
			//
			// Adding side only. A reducing side has no standalone cancel at all
			// (H-QUE-2) -- `enqueueCancel` refuses one loudly -- so widening the
			// trigger there would trade a real cancel for a per-tick SEV2.
			//
			// `cancelConfirmed` is the other end of the same rule. H-FAIL-3
			// says "off" means exchange-confirmed absent -- and it means it in
			// BOTH directions. A side a complete verifying read has already
			// found empty is off, whatever `LiveOrders` still says until the
			// next walk refreshes it, and reissuing the cancel every tick until
			// then is churn against the §16 budget rather than diligence.
			if !o.cancelConfirmed[side] &&
				(o.atRisk(side) > 0 ||
					(role == quote.RoleAdding && o.sweptOn(side))) {

				o.enqueueCancel(now, side, role)
			}
			continue
		}
		// H-Q-5b, on the REDUCING side, retired by SIZE rather than by price.
		//
		// Every state that designates a reducing side -- SKEWED, REDUCING and
		// SETTLING -- caps that side's aggregate at |q| (H-Q-5a), and `SizesFor`
		// has just computed `target` as that cap. Yet the only thing that would
		// otherwise resize the resting exit is `decideSide`, and `quote.Decide`
		// there is PRICE-only: it asks "is our order at the touch?" and returns no
		// move for an at-touch reducer WHATEVER its size. A reducer that is at the
		// touch but oversized -- an exchange-confirmed 12-contract exit against a
		// |q| of one, an order sized when |q| was larger and left behind when a
		// fill (or a positions walk that shrank q ahead of the orders walk that
		// still lists the order) reduced it -- sails past §6.5, leaving an
		// aggregate above |q|. A reducer above |q| is a reducing quote of |q| plus
		// an ADDING quote on the opposite side (A11, A12), which is precisely what
		// each of these states exists to switch off, and price-unchanged is
		// exactly when that is invisible. So the aggregate (RESTING + SENDING +
		// UNKNOWN + in-flight + unconfirmed-cancel, which is `atRisk`) is checked
		// against the freshly-capped target HERE.
		//
		// It is gated on the reducing ROLE and NOT on `gateStopped`. H-Q-5b names
		// SETTLING alongside REDUCING -- "REDUCING and SETTLING use
		// cancel-confirm-place whenever an overlap could exceed |q|" -- so the
		// obligation is not gate-failure-specific. Under §10.3, S=12 and an
		// ordinary legal fill can leave q = +/-1, and H-CLOSE-2 then enters
		// SETTLING at close_time - close_lead with `gateStopped` false; the
		// at-touch 12-contract order the price-only path leaves alone is exactly
		// the overshoot A12 forbids, and A12 is invariant at every tick, not only
		// during a sustained gate failure.
		//
		// One DEPENDENT cancel-confirm-place, never a standalone reducing-side
		// cancel: H-QUE-2 has no row for the latter, because cancelling the exit is
		// not work this harness does on its own account. This reuses the ordinary
		// cancel/sweep confirmation path -- the first leg retires every
		// possibly-live reducer, the replacement is gated on `ConfirmAbsent` (H-Q-9
		// clause 3, H-ORD-4, H-FAIL-3), and `build` sizes the remainder against the
		// shrunken aggregate, so no replacement overlaps a reducer still resting.
		//
		// It sits ABOVE the `!actionable` guard because its first leg is a CANCEL,
		// and a cancel that removes risk above |q| is exactly the reducing-risk
		// action every stop path keeps alive (I1) whether or not a placement could
		// be taken; `Conditions.Valid` still holds the replacement leg until the
		// side is actionable again. A reducer that is ALREADY the quantized |q| --
		// down to the 0.01-contract exit of a fractional canary -- has
		// `atRisk == target`, so `atRisk > target` is false and this fires on
		// genuine overshoot alone, never on a compliant exit: WINDING_DOWN forbids
		// adding but keeps a correctly capped reducer live. `cancelConfirmed` and
		// `enqueue`'s (market, side) dedup are the same two guards the `!wanted`
		// branch relies on, and together they keep repeated evaluations from
		// queuing a second cancel for one overhang; once `build` rebuilds the
		// aggregate to |q| the comparison never re-enters, so it settles without
		// churn.
		//
		// The `target > 0` guard is A4/I1, and it is NOT redundant. `SizesFor`
		// sets `HasReduce` for any q != 0 while `SizeR` caps `Reduce` at `funded`,
		// and `fundedReducer` answers 0 whenever the reducing side of the book has
		// no levels -- which `ResetOnReconnect` guarantees after every ABNORMAL
		// disconnect, and which also holds at startup with adopted inventory,
		// before the first snapshot lands. Without the guard `target` is 0 there,
		// EVERY resting exit reads as pure overshoot, and this branch -- which sits
		// above `!actionable` precisely so that cancels survive a stop -- would
		// DELETE the exit at the moment the harness is blind, with the replacement
		// leg held by `Conditions.Valid` until the side is actionable again. That
		// is the one thing I1 forbids: no stop path may stop reducing risk. An
		// unfundable reducer is "not placed" (SizeR); that is never a licence to
		// cancel the one already working. Overshoot that cannot yet be replaced is
		// strictly safer than no exit at all.
		if role == quote.RoleReducing && target > 0 &&
			!o.cancelConfirmed[side] && o.atRisk(side) > target {

			o.enqueue(now, quote.Intent{
				Market: o.r.cfg.Ticker, Side: side, Role: quote.RoleReducing,
				Kind: quote.KindCancelConfirmPlace, Reason: quote.ReasonReduce,
			})
			continue
		}
		_, roleActionable := o.pricingBook(role)
		if !actionable && !(role == quote.RoleReducing && roleActionable && !o.awaitCancelTruth) {
			// A13 / H-FAIL-4 / H-FAIL-5: no PLACEMENT decision may be taken
			// from a quarantined or stale book. Cancels are unaffected and were
			// handled above, which is the asymmetry every stop path in this
			// system has (I1).
			continue
		}
		if gateQuiet && !o.r.gate.F5Quarantined(ticker) {
			// H-Q-4, inside H-Q-4a's debounce. The book has stopped qualifying
			// and has not yet been failing long enough to earn the cancel, so
			// this window does exactly two things and no more: it places
			// NOTHING, because a gated-out interval pays every participant zero
			// and "do not place" is H-Q-4's own instruction from the first
			// frame; and it touches nothing that is already resting, because
			// HR-012 says the debounce exists to protect against churn on
			// transient blips and cancelling here would BE that churn.
			//
			// `continue` rather than a narrower guard inside `decideSide` is
			// deliberate: §6.5 answers an unrefreshed side with a requote or a
			// presence restoration, and both of those are writes derived from
			// the book we have just decided not to quote into. The cancel LEG of
			// a cancel-confirm-place is one of them.
			//
			// It sits BELOW the `!wanted` branch, so a market stopped for any
			// other reason still gets its adding side off during the window.
			// Suppressing that would let a thin book postpone an unrelated stop.
			continue
		}
		o.decideSide(now, side, role, target)
	}
}

// decideSide runs §6.5 for one side and queues what it asks for.
func (o *owner) decideSide(now time.Duration, side quote.Side, role quote.Role,
	target num.Qty) {

	book, allowed := o.pricingBook(role)
	if !allowed {
		return
	}
	levels := book.Yes()
	if side == quote.SideNo {
		levels = book.No()
	}

	ours, price, has := o.restingOn(side)
	ext := quote.ExternalBest(levels, ours)
	o.noteTouch(now, side, ext)

	otherPrice, hasOther := o.bestOn(side.Opposite())

	in := quote.RequoteInput{
		Side:        side,
		Role:        role,
		OurPrice:    price,
		OurSize:     o.atRisk(side),
		HasOurs:     has,
		Ext:         ext,
		TouchHeld:   o.touchHeld(now, side),
		StrandedFor: o.strandedFor(now, side),
		OtherPrice:  otherPrice,
		HasOther:    hasOther,
		Size:        target,
		// Headroom is read only when place-then-cancel is permitted, and it is
		// not. Left at zero so that a future build turning H-Q-9 on has to
		// supply it deliberately rather than inherit a stale value.
		Headroom: 0,
		// H-Q-9 stays OFF for the pilot: cancel-confirm-place everywhere
		// (pilot-plan §2.7, §7.1). This is the zero value and is written
		// explicitly anyway, because the flag is the single line between the
		// pilot's simple invariant and two of our orders live at once.
		AllowPlaceThenCancel: false,
	}

	rq := quote.Decide(in, o.p)
	if !rq.Move {
		return
	}
	if has && rq.Price == price {
		// Already there. `Decide` returns early on this, but the check is
		// repeated because `Move` with an unchanged price would enqueue a write
		// that cancels an order to replace it with itself.
		return
	}

	reason := quote.ReasonRequote
	switch {
	case role == quote.RoleReducing:
		reason = quote.ReasonReduce
	case rq.Trigger == quote.TriggerAbsent:
		reason = quote.ReasonPresence
	}

	kind := rq.Kind
	if !has {
		kind = quote.KindPlace
	}
	o.enqueue(now, quote.Intent{
		Market: o.r.cfg.Ticker, Side: side, Role: role,
		Kind: kind, Reason: reason,
	})
}

// enqueueCancel queues the retirement of a side.
//
// A standalone cancel is legal on the ADDING side only (H-QUE-2): a
// reducing-side cancel removes the exit, so it is only ever the first leg of a
// cancel-confirm-place. A caller asking to retire a reducing side outright is
// asking for something §6.6 does not have a row for, so it is refused loudly
// rather than downgraded into a shape the queue would accept.
func (o *owner) enqueueCancel(now time.Duration, side quote.Side, role quote.Role) {
	if role == quote.RoleReducing {
		if !o.reducerCancelPinged[side] {
			o.reducerCancelPinged[side] = true
			o.r.anom.raise(risk.Anomaly{
				Class: "REDUCER_CANCEL_REFUSED", Sev: risk.SEV2,
				Ticker: o.r.cfg.Ticker,
				Text: fmt.Sprintf("a standalone cancel was wanted for the %s "+
					"reducing side; H-QUE-2 has no row for one, because "+
					"cancelling the exit is not work this harness does on its "+
					"own account. Nothing was queued, and this is reported once "+
					"per side rather than once per tick", side),
			})
		}
		return
	}
	o.enqueue(now, quote.Intent{
		Market: o.r.cfg.Ticker, Side: side, Role: role,
		Kind: quote.KindCancel, Reason: quote.ReasonCancel,
	})
}

// enqueue admits one intent, refusing duplicates of work already pending.
//
// §6.6's queue holds INTENTS re-evaluated at dequeue, not requests, so a second
// intent for a side that already has one queued is not additional information --
// it is the same decision taken again from the same state, and admitting it
// would let a quiet market accumulate one entry per owner tick.
func (o *owner) enqueue(now time.Duration, in quote.Intent) {
	for _, req := range o.inflight {
		if req.Market == in.Market && req.Side == in.Side {
			return
		}
	}
	for _, req := range o.retries {
		if req.Market == in.Market && req.Side == in.Side {
			return
		}
	}
	for _, pending := range o.r.queue.Pending() {
		if pending.Market == in.Market && pending.Side == in.Side &&
			pending.Op() == in.Op() {
			return
		}
	}
	if _, err := o.r.queue.Enqueue(now, in); err != nil {
		o.r.anom.raise(risk.Anomaly{
			Class: "INTENT_REFUSED", Sev: risk.SEV2, Ticker: in.Market,
			Text: fmt.Sprintf("the write queue refused a %s/%s intent: %v",
				in.Kind, in.Reason, err),
		})
	}
}

// pump is the sole dispatch authority; every launch is charged before handoff.
func (o *owner) pump(now time.Duration, writes chan<- writeRequest) {
	o.updateThrottle(now)
	params := o.p
	if o.throttled {
		params.WriteRate /= 2
	}
	o.capacity, o.capCarry = refillWrites(o.capacity, params, now-o.capAt, o.capCarry)
	o.capAt = now

	for n := 0; n < dispatchWorkers; n++ {
		if o.pumpRetry(now, writes) {
			continue
		}
		d, ok := o.r.queue.Dequeue(o.conditions(now), o.capacity)
		if !ok {
			return
		}

		req, err := o.build(d)
		if err != nil {
			// The dispatch cannot be built, so the intents it would have discharged
			// are dropped rather than left to be re-selected forever at a class that
			// keeps rising. Dropping is §6.6's own answer to an intent whose
			// condition no longer holds, and "we cannot express this write" is a
			// condition that will not hold on the next tick either.
			for _, id := range d.IDs {
				o.r.queue.Drop(id)
			}
			o.r.anom.raise(risk.Anomaly{
				Class: "WRITE_NOT_BUILDABLE", Sev: risk.SEV2, Ticker: d.Market,
				Text: fmt.Sprintf("a %s on %s/%s was selected but could not be "+
					"built: %v", d.Op, d.Market, d.Side, err),
			})
			return
		}

		// A read-only process rehearses the exact decision but never enters the
		// dispatch-authority path. In particular it takes no ownership reservation:
		// owned_order is proof that a write was licensed to leave, not a telemetry
		// table for a write the invocation forbade. Dropping the selected intents
		// also prevents the guarded-refusal completion loop that previously minted
		// and abandoned rows at SQLite speed.
		if !o.r.cfg.Live {
			if o.r.qual != nil {
				fp := wouldWriteFingerprint(req, o.global, o.market,
					o.r.gate.Generation())
				if err := o.r.qual.RecordWouldWrite(fp, time.Now().UTC()); err != nil {
					o.r.failQualification(fmt.Errorf("recording would-write: %w", err))
				}
			}
			for _, id := range d.IDs {
				o.r.queue.Drop(id)
			}
			return
		}

		// The capacity is charged BEFORE the send and never after. `Capacity.Take`
		// is the caller's half of H-QUE-3, and charging it on completion would let
		// the same token fund every write issued while one was in flight.
		o.capacity = o.capacity.Take(d.Grant)
		select {
		case writes <- req:
			o.inflight = append(o.inflight, &req)
		default:
			o.capacity = releaseWrite(o.capacity, o.p, d.Grant, false)
			// No bytes were sent. Release the selected intent so the next
			// owner evaluation rebuilds price, size and role from current truth.
			for _, id := range d.IDs {
				o.r.queue.Drop(id)
			}
			return
		}
	}
}

// conditions is §6.6's re-evaluation, rebuilt at every dequeue and cached
// nowhere. A condition that was true 30 seconds ago is exactly what "not
// pre-built requests" is guarding against.
func (o *owner) conditions(now time.Duration) quote.Conditions {
	q := o.r.pf.Q(o.r.cfg.Ticker)
	return quote.Conditions{
		Now:    now,
		Global: o.global,
		AboveSoft: map[string]bool{
			o.r.cfg.Ticker: q.Abs() > o.p.InvSoft,
		},
		Valid: func(in quote.Intent) bool {
			// A placement is still wanted only while the market may place at
			// all. A cancel is always still wanted: it can only reduce
			// exposure, and an intent to remove an order does not stop being
			// true because the book moved.
			if in.Op() == quote.OpCancel {
				return true
			}
			if o.awaitCancelTruth {
				return false
			}
			if _, allowed := o.pricingBook(in.Role); !allowed {
				return false
			}
			// H-Q-4, applied to work that was decided BEFORE the book stopped
			// qualifying. Without this the rule has a hole exactly one dequeue
			// wide: `evaluate` stops enqueuing, and the placement already
			// sitting in the queue -- selected, priced at dispatch from the
			// current book -- goes out anyway, into the interval that pays
			// nobody. §6.6 holds intents re-evaluated at dequeue for this.
			return !o.f5GateFailBlocksPlacement(now, in)
		},
	}
}

// build turns a selected dispatch into the concrete write.
//
// The coid is minted HERE, in the owner, and not in the dispatcher. H-ORD-1's
// determinism is what makes H-ORD-2b's same-coid recovery possible at all, and
// the sequence it counts is owner state: a counter living in the goroutine that
// also blocks on the network would advance on retries it did not author.
func (o *owner) build(d quote.Dispatch) (writeRequest, error) {
	req := writeRequest{
		IDs: append([]uint64(nil), d.IDs...), Market: d.Market,
		Side: d.Side, Role: d.Role, Op: d.Op, Grant: d.Grant, class: d.Class,
	}

	if d.Op == quote.OpCancel {
		seen := make(map[string]bool)
		for _, lo := range o.r.pf.LiveOrders() {
			if lo.Ticker != d.Market || lo.Side != d.Side {
				continue
			}
			if _, absent := o.absentOrders[lo.OrderID]; absent {
				continue
			}
			cents, exact := rest.CentsExact(lo.Price4)
			if !exact {
				cents = 0
			}
			seen[lo.OrderID] = true
			req.Orders = append(req.Orders, rest.Order{
				OrderID: lo.OrderID, Ticker: lo.Ticker, Side: lo.Side,
				Price4: lo.Price4, PriceCents: cents, Fractional: !exact,
				Remaining: lo.Remaining, Status: rest.StatusResting,
			})
		}
		// Everything else of ours this side may still have live that no complete
		// orders walk has listed into `LiveOrders` yet. See `unlistedOn`.
		for _, ord := range o.unlistedOn(d.Market, d.Side) {
			if seen[ord.OrderID] {
				continue
			}
			seen[ord.OrderID] = true
			req.Orders = append(req.Orders, ord)
		}
		if len(req.Orders) == 0 {
			// EMPTY IS NOT ALWAYS AN ERROR, and this is the branch H-ORD-2a
			// forces. An UNKNOWN create has quantity in every aggregate cap
			// (H-ORD-2 clause 6) and no order id anywhere, so "we hold no id for
			// this side" and "nothing of ours rests on this side" are different
			// statements and only the second one licenses giving up.
			//
			// `writeRequest.Orders` documents the empty case as legitimate:
			// H-ORD-4's sweep then issues no DELETE and performs only the
			// verifying read, "which is still the read that turns absence into a
			// fact (H-FAIL-3)". That read is the whole point here -- it either
			// finds the order, which puts an id in `sweptOrders` for the next
			// tick to cancel, or it finds nothing of ours on this side, which is
			// the exchange-confirmed absence that ends the obligation.
			//
			// Refusing instead would report a WRITE_NOT_BUILDABLE SEV2 per tick
			// and leave an order live and fillable for up to `position_poll_s`
			// with the harness believing it had asked for it back.
			if d.Market != o.r.cfg.Ticker || o.atRisk(d.Side) <= 0 {
				return writeRequest{}, fmt.Errorf(
					"nothing of ours rests on %s/%s", d.Market, d.Side)
			}
		}
		return req, nil
	}

	price, ok := o.f5TargetPrice(d.Side, d.Role)
	if !ok {
		return writeRequest{}, fmt.Errorf("no external touch to place against")
	}
	size, bound := o.targetSize(d.Side, d.Role)
	if size <= 0 {
		return writeRequest{}, fmt.Errorf("the side is already carrying its "+
			"aggregate target, so the remainder is %s", size.Wire())
	}

	o.coidSeq++
	// The pilot quotes ONE market, so the market index is 0. It is written as a
	// named constant rather than a bare literal because `ParseCoid` reads it
	// back as the market this order belongs to, and a second market added
	// without giving it a distinct index would attribute both to the first.
	coid, err := rest.Coid(o.r.runID, pilotMarketIdx, d.Side, o.coidSeq)
	if err != nil {
		return writeRequest{}, err
	}
	order, err := rest.NewCreateOrder(d.Market, d.Side, price, size, bound, coid)
	if err != nil {
		return writeRequest{}, err
	}
	req.Order = order
	if err := o.checkPlacementCapital(req); err != nil {
		return writeRequest{}, err
	}
	return req, nil
}

// pilotMarketIdx is the `%03d` field of H-ORD-1's coid. See `build`.
const pilotMarketIdx = 0

// targetPrice re-reads the touch at dispatch rather than carrying the price the
// decision was taken at.
//
// §6.6 is explicit that the queue holds intents and not requests, and a price
// captured at enqueue is the request half of exactly that. The book has moved by
// the time a write is admitted through the rate limiter, and placing at the old
// touch is how an order arrives already behind.
func (o *owner) targetPrice(side quote.Side) (int, bool) {
	book := o.r.book.Book(o.r.cfg.Ticker)
	if book == nil {
		return 0, false
	}
	levels := book.Yes()
	if side == quote.SideNo {
		levels = book.No()
	}
	ours, _, _ := o.restingOn(side)
	ext := quote.ExternalBest(levels, ours)
	if !ext.Found || !quote.ValidPrice(ext.Price) {
		return 0, false
	}

	price := ext.Price
	if other, has := o.bestOn(side.Opposite()); has {
		max, ok := quote.MaxOpposite(other)
		if !ok {
			return 0, false
		}
		if price > max {
			// H-CO-6. `Decide` already clamps a REDUCING side here and blocks an
			// adding one outright; this repeats the bound at the last moment
			// before the bytes are built, because the opposite side may have
			// been placed between the decision and the dispatch.
			price = max
		}
	}
	if !quote.ValidPrice(price) {
		return 0, false
	}
	return price, true
}

// targetSize is the REMAINDER: the aggregate the side should carry, less what is
// already working on it (H-Q-5b).
//
// The second result is H-CO-4b's `derivedFrom` bound -- |q| for a reducer,
// size_A for an adding quote -- which `rest.NewCreateOrder` validates the count
// against. Passing it rather than zero is what makes an over-sized reducer a
// construction error instead of a placed order.
func (o *owner) targetSize(side quote.Side, role quote.Role) (num.Qty, num.Qty) {
	q := o.r.pf.Q(o.r.cfg.Ticker)
	sz := quote.SizesFor(quote.SizeInput{
		State:         o.market,
		Q:             q,
		Funded:        o.f5FundedReducer(q),
		PastFinalLead: quote.PastFinalLead(o.untilCloseOrZero()),
	}, o.p)

	target, bound := sz.Add, quote.SizeA(q, o.p)
	if role == quote.RoleReducing {
		target, bound = sz.Reduce, q.Abs()
	}
	remainder := target - o.atRisk(side)
	if remainder < 0 {
		remainder = 0
	}
	if remainder > bound {
		remainder = bound
	}
	return remainder, bound
}

// fundedReducer converts capital into the contract count §6.2's size_R caps
// against.
//
// It sizes against `now` -- what can be funded without cancelling anything --
// and never against `afterCuts`. `ReducingBudget` states the reason: capital
// tied up in an adding order is not free until the exchange confirms the cancel,
// and a reducer sized against the post-cut figure before the cancels land gets
// an `insufficient_balance` reject, which H-CAP-5 makes a correctness failure
// and a global WINDING_DOWN rather than a market condition.
func (o *owner) fundedReducer(q num.Qty) num.Qty {
	reducing, held := quote.ReducingSide(q)
	if !held {
		return 0
	}
	// Priced at the BOOK's touch, not at our own resting price.
	//
	// `funded` bounds the aggregate the exit may carry, so the question it
	// answers is "how many contracts can this capital buy at the price the exit
	// would be placed at" -- and §6.5 places at the touch. Pricing it off our
	// own resting order would size the exit against a price we are no longer
	// quoting at the moment the touch has moved, which is exactly when the
	// reducer is being resized.
	var price int
	{
		book := o.r.book.Book(o.r.cfg.Ticker)
		if book == nil {
			return 0
		}
		levels := book.Yes()
		if reducing == quote.SideNo {
			levels = book.No()
		}
		best, _, ok := levels.Max()
		if !ok {
			return 0
		}
		price = best
	}
	now, _ := risk.ReducingBudget(o.exposures(), o.p)
	return risk.FundedContracts(now, num.Price4FromCents(price))
}

// exposures is the committed-collateral picture §10.2's caps are measured
// against.
//
// Held positions are valued at SETTLEMENT ($1.00), for the reason `policy.go`
// gives at length: the positions endpoint answers with the position and not what
// it cost, and overstating what a position ties up can only shrink a budget,
// whereas understating it produces the `insufficient_balance` reject H-CAP-5
// treats as a correctness failure.
func (o *owner) exposures() []risk.Exposure {
	by := make(map[string]*risk.Exposure)
	get := func(t string) *risk.Exposure {
		e, ok := by[t]
		if !ok {
			e = &risk.Exposure{Ticker: t}
			by[t] = e
		}
		return e
	}
	for t, q := range o.r.pf.Positions() {
		get(t).Position += risk.SideCost(q, risk.SettlementPrice4)
	}
	for _, lo := range o.r.pf.LiveOrders() {
		if _, absent := o.absentOrders[lo.OrderID]; absent {
			continue
		}
		e := get(lo.Ticker)
		reducing, held := quote.ReducingSide(o.r.pf.Q(lo.Ticker))
		if held && lo.Side == reducing {
			e.Reducing += risk.SideCost(lo.Remaining, lo.Price4)
			continue
		}
		e.Adding += risk.SideCost(lo.Remaining, lo.Price4)
	}
	// The owner reserves collateral at handoff, before any second build.
	add := func(market string, side quote.Side, qty num.Qty, price int64) {
		e := get(market)
		reducing, held := quote.ReducingSide(o.r.pf.Q(market))
		if held && side == reducing {
			e.Reducing += risk.SideCost(qty, price)
		} else {
			e.Adding += risk.SideCost(qty, price)
		}
	}
	for _, req := range o.inflight {
		if req.Op == quote.OpPlace {
			if o.hasListedCreate(req.Order.ClientOrderID(), req.Market, req.Side) {
				continue
			}
			if _, counted := o.pending[req.Order.ClientOrderID()]; !counted {
				add(req.Market, req.Side, req.Order.Count(), num.Price4FromCents(req.Order.PriceCents()))
			}
		}
	}
	for coid, u := range o.pending {
		if o.hasListedCreate(coid, o.r.cfg.Ticker, u.side) {
			continue
		}
		add(o.r.cfg.Ticker, u.side, u.qty, num.Price4FromCents(u.cents))
	}
	out := make([]risk.Exposure, 0, len(by))
	for _, e := range by {
		out = append(out, *e)
	}
	return out
}

// restingOn is our own aggregate presence on one side, in the shape
// `ExternalBest` subtracts.
//
// It returns the AGGREGATE (H-Q-5b): exchange-confirmed resting, plus the write
// currently in flight, plus every unresolved create's maximum possibly-live
// quantity. An order id a complete cancel sweep proved absent is excluded even
// if an older portfolio walk still lists it. Leaving any possibly-live size
// out would leave it in the external touch, and we would chase ourselves
// (H-Q-10).
func (o *owner) restingOn(side quote.Side) ([]quote.Resting, int, bool) {
	byPrice := make(map[int]num.Qty)
	for _, lo := range o.r.pf.LiveOrders() {
		if lo.Ticker != o.r.cfg.Ticker || lo.Side != side {
			continue
		}
		if _, absent := o.absentOrders[lo.OrderID]; absent {
			continue
		}
		cents, exact := rest.CentsExact(lo.Price4)
		if !exact {
			// H-CO-3a. A resting price that is not a whole cent cannot be
			// subtracted from a book indexed by whole cents, and guessing which
			// level it belongs to would delete somebody else's liquidity.
			continue
		}
		byPrice[cents] += lo.Remaining
	}
	for _, req := range o.inflight {
		if req.Market == o.r.cfg.Ticker && req.Side == side && req.Op == quote.OpPlace {
			if o.hasListedCreate(req.Order.ClientOrderID(), req.Market, req.Side) {
				continue
			}
			if _, counted := o.pending[req.Order.ClientOrderID()]; !counted {
				byPrice[req.Order.PriceCents()] += req.Order.Count()
			}
		}
	}
	for coid, u := range o.pending {
		if u.side == side {
			if o.hasListedCreate(coid, o.r.cfg.Ticker, u.side) {
				continue
			}
			byPrice[u.cents] += u.qty
		}
	}

	out := make([]quote.Resting, 0, len(byPrice))
	best, has := 0, false
	for price, size := range byPrice {
		if size <= 0 {
			continue
		}
		out = append(out, quote.Resting{Price: price, Size: size})
		if !has || price > best {
			best, has = price, true
		}
	}
	return out, best, has
}

// unlistedOn is every order of ours on one side that a cancel can NAME but that
// `risk.Portfolio.LiveOrders` does not hold yet.
//
// Two sources, and they are the two ways an order id reaches this process
// outside a portfolio walk:
//
//   - `pending`, for a create whose acknowledgement carried an `order_id`. The
//     order demonstrably exists; `Portfolio.ReplaceOrders` is wholesale from a
//     complete walk (H-POS-4) and the next one is up to `position_poll_s` away,
//     so between them the only record of the id is here.
//   - `sweptOrders`, for an order a cancel's VERIFYING READ found resting. This
//     covers the UNKNOWN create, which has no id at all until something
//     positively identifies it (H-ORD-2a), and the order placed by a previous
//     incarnation that §7.5 adopted.
//
// The result is sorted by order id. Map iteration order is random in Go, and a
// cancel whose target list is shuffled between two ticks is a write nobody can
// replay -- the scenario runner, the qualification evidence and every test that
// asserts on `deletedIDs` would each see a different history of the same run.
func (o *owner) unlistedOn(market string, side quote.Side) []rest.Order {
	var out []rest.Order
	for _, u := range o.pending {
		if u.side != side || u.id == "" {
			continue
		}
		out = append(out, rest.Order{
			OrderID: u.id, Ticker: market, Side: side,
			Price4: num.Price4FromCents(u.cents), PriceCents: u.cents,
			Remaining: u.qty, Status: rest.StatusResting,
		})
	}
	for _, ord := range o.sweptOrders {
		if ord.Ticker != market || ord.Side != side {
			continue
		}
		out = append(out, ord)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].OrderID < out[j].OrderID })
	return out
}

// sweptOn reports whether a verifying read has SEEN one of ours resting on this
// side and no complete read has since said otherwise.
//
// It is a presence question and never a quantity one: these orders are already
// counted in `atRisk` through `LiveOrders` or `pending`, and adding their size a
// second time would overstate the aggregate every cap is measured against
// (H-Q-5b) -- which on a reducing side is a reducer that never gets placed.
func (o *owner) sweptOn(side quote.Side) bool {
	for _, ord := range o.sweptOrders {
		if ord.Ticker == o.r.cfg.Ticker && ord.Side == side {
			return true
		}
	}
	return false
}

// noteSwept records what a cancel's VERIFYING READ found still resting.
//
// Wholesale from a COMPLETE read and from nothing else. `SweepResult.Walk` is
// the last verifying read and `Replaces()` is `wsx`'s own test for one that
// finished; an incomplete read is H-PAGE-1's "stale, never empty" and may
// neither add an obligation nor retire one. That asymmetry is H-FAIL-3 exactly:
// the only thing that ends a cancellation obligation is the exchange saying the
// order is gone, and a read that did not finish did not say it.
//
// Both sets are kept. `StillResting` is the requested orders the sweep could not
// remove -- those are the SEV1 `SWEEP_INCOMPLETE` case and are unambiguously
// still live -- and `OtherOurs` is every other `lipH-` order in the ticker,
// which is where an acked-but-unlisted or UNKNOWN create of ours turns up.
// `rest.CancelAndSweep` deliberately does not cancel `OtherOurs` itself, because
// on a halt that set contains the reducing quote and A4 requires it stay alive;
// deciding which of them to retire is this file's job, and `evaluate` does it
// per side from §5.2.
func (o *owner) noteSwept(market string, sweep rest.SweepResult) {
	if !sweep.Replaces() {
		return
	}
	for id, ord := range o.sweptOrders {
		if ord.Ticker == market {
			delete(o.sweptOrders, id)
		}
	}
	record := func(orders []rest.Order) {
		for _, ord := range orders {
			if ord.OrderID == "" {
				continue
			}
			if ord.Ticker != "" && ord.Ticker != market {
				continue
			}
			ord.Ticker = market
			o.sweptOrders[ord.OrderID] = ord
		}
	}
	record(sweep.StillResting)
	record(sweep.OtherOurs)
}

// clearSwept drops the entries a complete orders walk has since listed.
//
// Listing is the ONLY release here, exactly as in `clearListed`, and for the
// same reason: the order is now in `Portfolio.LiveOrders`, so `build` reaches it
// there and a duplicate record would be a second copy of one fact. Absence from
// the walk releases nothing (H-ORD-2a) -- what retires an entry that the walk
// does not list is the next sweep's own complete verifying read.
func (o *owner) clearSwept() {
	if len(o.sweptOrders) == 0 {
		return
	}
	for _, lo := range o.r.pf.LiveOrders() {
		delete(o.sweptOrders, lo.OrderID)
	}
}

// bestOn is our own best price on one side, for H-CO-6.
func (o *owner) bestOn(side quote.Side) (int, bool) {
	_, price, has := o.restingOn(side)
	return price, has
}

// atRisk is the aggregate every size cap is evaluated against (H-Q-5b, A11).
func (o *owner) atRisk(side quote.Side) num.Qty {
	ours, _, _ := o.restingOn(side)
	var total num.Qty
	for _, r := range ours {
		total += r.Size
	}
	return total
}

// noteTouch advances §6.5's two clocks for one side.
func (o *owner) noteTouch(now time.Duration, side quote.Side, ext quote.External) {
	i := int(side)

	if !ext.Found {
		o.touchFound[i] = false
		o.strandedNow[i] = false
		return
	}
	if !o.touchFound[i] || o.touchPrice[i] != ext.Price {
		o.touchPrice[i], o.touchFound[i], o.touchSince[i] = ext.Price, true, now
	}

	_, price, has := o.restingOn(side)
	if !has {
		o.strandedNow[i] = false
		return
	}
	away, _ := quote.BehindBy(price, ext)
	if away < 0 {
		away = -away
	}
	stranded := away >= o.p.StaleBidTicks
	if stranded && !o.strandedNow[i] {
		// The CONDITION's age, started when it began rather than when the price
		// last moved. A touch that flickers every 200ms must not reset this.
		o.strandedSince[i] = now
	}
	o.strandedNow[i] = stranded
}

func (o *owner) touchHeld(now time.Duration, side quote.Side) time.Duration {
	i := int(side)
	if !o.touchFound[i] {
		return 0
	}
	return now - o.touchSince[i]
}

func (o *owner) strandedFor(now time.Duration, side quote.Side) time.Duration {
	i := int(side)
	if !o.strandedNow[i] {
		return 0
	}
	return now - o.strandedSince[i]
}

// applyWriteResult folds the dispatcher's answer back into the queue and the
// risk model.
func (o *owner) applyWriteResult(res writeResult) {
	for i, req := range o.inflight {
		if sameWrite(*req, res.Req) {
			o.inflight = append(o.inflight[:i], o.inflight[i+1:]...)
			if len(o.inflight) == 0 {
				o.inflight = nil
			}
			break
		}
	}
	o.r.anom.raiseAll(res.Anomalies)
	// The worker slot always comes back; the TOKEN comes back only when nothing
	// left the process. A write refused by H-STORE-3 or rebuilt by the owner
	// spent no exchange write, and charging the §16 bucket for it would let a
	// store outage spend the reducer's share of the budget on nothing at all.
	o.capacity = releaseWrite(o.capacity, o.p, res.Req.Grant, res.Sent)
	if res.Req.Op == quote.OpPlace {
		o.observeRejectResponse(res.Req.Market, res.Create, res.Sent)
	}
	if o.retryThrottled(res) {
		return
	}

	// A WRITE THAT DID NOT COMPLETE MUST RELEASE ITS INTENTS, and this is the
	// least obvious rule in the file.
	//
	// `Queue.commit` advances a DEPENDENT intent's first leg to `StageFirstSent`
	// at DEQUEUE -- "that one line is H-Q-9a: dispatch is not confirmation" --
	// and leaves it in the queue. `Intent.Dispatchable()` is false at that stage,
	// and `Conditions.stillWanted` deliberately never drops it ("a write cannot
	// be un-sent"). So an intent whose write did not reach a terminal answer is
	// not merely delayed: it occupies its (market, side) FOREVER, it can never be
	// selected again, and `enqueue`'s duplicate check then refuses every
	// replacement for that side. The market stops quoting and nothing says so.
	//
	// Dropping is safe precisely because it is not a retreat: `evaluate` re-runs
	// §6.5 on the next tick from current conditions and re-enqueues if the
	// decision still holds, which is what §6.6 means by holding intents rather
	// than requests.
	if res.Err != nil {
		for _, id := range res.Req.IDs {
			o.r.queue.Drop(id)
		}
		// H-VER-1. A guarded refusal releases the intents exactly as above --
		// the side must not wedge at stage-first-sent whatever stopped the
		// write -- but it raises NOTHING. `WRITE_FAILED` is a report that the
		// EXCHANGE did not complete something, and a read-only rehearsal did
		// not ask it to: this process is doing precisely what it was started to
		// do. Raising here would fill the anomaly journal with a SEV2 per tick
		// for the whole of a qualification run, which is how a real fault
		// arriving in the middle of one becomes invisible.
		//
		// §6.5 re-decides on the next tick and is refused again, forever, which
		// is the correct behaviour for a process that may not trade.
		var refused *rest.WriteRefused
		if errors.As(res.Err, &refused) {
			return
		}
		o.r.anom.raise(risk.Anomaly{
			Class: "WRITE_FAILED", Sev: risk.SEV2, Ticker: res.Req.Market,
			Text: fmt.Sprintf("the %s on %s/%s did not complete (%v); its "+
				"intents are released so the side is not wedged at "+
				"stage-first-sent, and §6.5 re-decides on the next tick",
				res.Req.Op, res.Req.Market, res.Req.Side, res.Err),
		})
		return
	}

	if res.Req.Op == quote.OpCancel {
		// FIRST, and on both branches. The verifying read is the same read
		// whether or not it declared the side clean, and what it saw is what
		// decides which orders the next tick can still name. Recording it only
		// on the unverified branch would lose the one case this exists for: a
		// sweep that cleanly removed what we asked for and reported an
		// acked-but-unlisted order of ours still resting beside it.
		o.noteSwept(res.Req.Market, res.Sweep)
		if res.Absent {
			// The sweep says the order is absent, but a just-before-DELETE fill
			// may have changed q. Drop the dependent placement and rederive it
			// only after fresh fills, orders, and positions have been applied.
			// This is deliberately independent of reduced_by, which is no fill
			// report and whose response identity is not yet validated here.
			o.awaitCancelTruth = true
			o.cancelTruthAfter = o.r.ex.Clock.Now().Mono
			for _, id := range res.Req.IDs {
				o.r.queue.Drop(id)
			}
			o.offerToken(o.reconcileOut, o.reconcileToken)
			// The complete verifying read found nothing of ours on this side.
			// Record the ids represented by an older portfolio walk before the
			// next reconciliation. Keep this evidence by id across a new create;
			// the side-wide cancelConfirmed flag must clear on that create.
			requested := make(map[string]struct{}, len(res.Req.Orders))
			for _, lo := range o.r.pf.LiveOrders() {
				if lo.Ticker == res.Req.Market && lo.Side == res.Req.Side {
					o.absentOrders[lo.OrderID] = struct{}{}
				}
			}
			for _, ord := range res.Req.Orders {
				if ord.OrderID != "" && ord.Ticker == res.Req.Market &&
					ord.Side == res.Req.Side {
					o.absentOrders[ord.OrderID] = struct{}{}
					requested[ord.OrderID] = struct{}{}
				}
			}
			// A known-id ACK that the cancel named has also been positively
			// retired, even if no portfolio walk ever listed it. Otherwise its
			// pending quantity would block the replacement indefinitely. An
			// UNKNOWN create has no id to match and retains its maximum live size.
			for coid, p := range o.pending {
				if p.side != res.Req.Side || !p.acked || p.id == "" {
					continue
				}
				if _, named := requested[p.id]; named {
					delete(o.pending, coid)
				}
			}
			// H-ORD-4 and H-FAIL-3: only the complete verifying sweep can
			// discharge the cancellation obligation. A 2xx alone cannot. The
			// dependent intent was discarded above so a fresh position walk will
			// rederive its role and size. Keep the obligation discharged until a
			// newer orders walk; otherwise §5.2 would keep cancelling the same
			// stale LiveOrders id on every owner tick.
			o.cancelConfirmed[res.Req.Side] = true
			return
		}
		// Not verified absent. The intents are RELEASED for the reason above:
		// a cancel-confirm-place whose cancel did not confirm sits at
		// stage-first-sent, and only `ConfirmAbsent` moves it -- which is
		// exactly what did not happen. Left in place it would hold this side
		// against every future intent for the life of the process.
		//
		// The orders themselves stay in the risk model regardless. H-FAIL-3: a
		// cancel we requested and did not see confirmed is a live, fillable
		// order, and it keeps its quantity in every aggregate cap until the
		// exchange says otherwise. Releasing the INTENT and keeping the ORDER
		// are the two halves of the same reading.
		for _, id := range res.Req.IDs {
			o.r.queue.Drop(id)
		}
		o.r.anom.raise(risk.Anomaly{
			Class: "CANCEL_UNVERIFIED", Sev: risk.SEV2, Ticker: res.Req.Market,
			Text: fmt.Sprintf("the cancel of %d order(s) on %s/%s did not come "+
				"back verified absent (%s); H-FAIL-3 keeps every one of them in "+
				"the risk model and in every aggregate cap until the exchange "+
				"confirms it gone, and §6.5 re-decides the side on the next tick",
				len(res.Req.Orders), res.Req.Market, res.Req.Side,
				res.Sweep.Outcome),
		})
		return
	}

	create := res.Create
	o.stopForInsufficientBalance(res.Req.Market, create)

	// EVERY create that may have left quantity live enters the aggregate HERE,
	// before anything else reads it. A complete orders walk that lists the coid
	// moves it into LiveOrders; a complete cancel sweep can retire a named ACKed
	// order before that walk. An UNKNOWN create keeps its maximum possibly-live
	// quantity until positive resolution.
	//
	// Both outcomes, not just the unknown one. `CreateRejected` is the single
	// case with nothing live -- `MaxLive` is zero only there -- so the test is
	// on the quantity rather than on the outcome, and an acked order is carried
	// for exactly the same reason an unknown one is: `Portfolio.ReplaceOrders`
	// is wholesale from a complete walk (H-POS-4), so until the next one lands
	// this order is in no aggregate the sizing can see.
	//
	// H-ORD-2 clause 6 is the unknown half: "an UNKNOWN order's maximum
	// possibly-live quantity STAYS in the risk model and in every aggregate cap
	// (H-Q-5b, H-CAP-7) until it is positively resolved."
	if create.MaxLive > 0 {
		o.pending[create.Coid] = pendingOrder{
			side:  res.Req.Side,
			cents: res.Req.Order.PriceCents(),
			qty:   create.MaxLive,
			at:    o.r.ex.Mono(),
			acked: create.Outcome.Exists(),
			// The id from the acknowledgement, when there is one. It is empty
			// for an UNKNOWN create and that is the honest answer: H-ORD-2a
			// deleted the "declare it never landed" branch, so an id we do not
			// have is resolved positively by a walk or by a sweep, never
			// guessed.
			id: create.OrderID,
		}
		// Something may now be resting on this side again, so the last
		// verifying read's "nothing of ours here" no longer describes it.
		o.cancelConfirmed[res.Req.Side] = false
	}

	switch {
	case create.Outcome.Exists():
		// H-Q-9a: the leg gate opens on the ACK and not on the dispatch. For a
		// cancel-confirm-place this is the terminal leg; for a first placement
		// it discharges the intent.
		for _, id := range res.Req.IDs {
			o.r.queue.AckPlace(id)
		}
		if create.Filled > 0 {
			// §8.2. The ack's own fill count moves `q` now rather than waiting
			// for the fills walk, and `ApplyAck` is what keeps the two from
			// double-counting when the walk catches up.
			fe := o.r.pf.ApplyAck(risk.AckFill{
				OrderID: create.OrderID, Ticker: res.Req.Market,
				Side: res.Req.Side, Filled: create.Filled,
			})
			o.r.anom.raiseAll(fe.Anomalies)
			if fe.Stop {
				o.requestStop("ack_fill", res.Req.Market)
			}
			// §7.9. No baseline test is needed on this source and none would
			// mean anything: this is an acknowledgement of a create THIS
			// process made, and `serve` starts the dispatcher only after
			// `install` returns, so there is no acknowledgement here that is
			// not live.
			//
			// It sits below `fe.Stop` for consistency with the other call
			// site, but the ordering buys less here and the difference is
			// worth stating rather than implying: `risk.AckFill` carries no
			// `is_taker` and no fee, so `ApplyAck` can only stop on an order
			// identity or direction conflict. An ack that filled and is LATER
			// reported as a taker by the authoritative walk cannot rewrite
			// this cause -- first-writer-wins keeps `canary_ack_fill`. That is
			// the correct trade on this rung, where the two causes reach the
			// same operator action, and it would not be on a rung where they
			// did not.
			o.canaryStop("canary_ack_fill", res.Req.Market)
		}
		if !res.Bound && create.OrderID != "" {
			// The binding is `dispatch.go`'s to submit, inline, on the
			// `CreateResult`. If it did not happen the reservation stays
			// unresolved, and while it does every fill on this order DEFERS
			// rather than applying -- past 120 s that is a SEV2
			// `FILL_UNCLASSIFIABLE` per trade, repeated. The `wsx` order-walk
			// rebind will close it one poll later, which is the safety net and
			// not the normal path.
			o.r.anom.raise(risk.Anomaly{
				Class: "BINDING_NOT_SUBMITTED", Sev: risk.SEV1,
				Ticker: res.Req.Market,
				Text: fmt.Sprintf("order %s acked for coid %s but no binding "+
					"was submitted on the dispatch path; our own fills on it "+
					"defer until the next orders walk rebinds it",
					create.OrderID, create.Coid),
			})
		}

	case create.Outcome == rest.CreateRejected:
		// A definite rejection: nothing exists and nothing is at risk. The
		// intents are dropped rather than left to age into a higher class,
		// because the write was made and answered -- re-selecting it would send
		// the same rejected order again.
		for _, id := range res.Req.IDs {
			o.r.queue.Drop(id)
		}

	default:
		// CreateUnknown. The intents are dropped for the same reason a rejection
		// drops them -- the write happened -- but the order may exist, so it
		// stays in `unresolved` above and keeps occupying the aggregate. §7.2's
		// resolution is the next complete orders walk listing the coid.
		for _, id := range res.Req.IDs {
			o.r.queue.Drop(id)
		}
	}

	if create.ReconcileNow() {
		o.offerToken(o.reconcileOut, o.reconcileToken)
	}

	o.clearListed()
	o.escalateUnresolved()
}

// escalateUnresolved is §7.2's `unknown_ping_s`.
//
// One anomaly per coid, not one per tick: an order stuck for an hour is one
// condition an operator needs told about once, and repeating it every 250 ms is
// how the alert that matters gets filtered out. The entry itself is NOT dropped
// -- H-ORD-2 clause 6 keeps it in every cap until it is positively resolved, and
// growing quiet about it does not resolve it.
func (o *owner) escalateUnresolved() {
	now := o.r.ex.Mono()
	for coid, u := range o.pending {
		// An ACKED order waiting for its first walk is not an anomaly, it is
		// younger than one `position_poll_s`. Only an order whose existence was
		// never established is worth waking an operator about.
		if u.acked || u.pinged || now-u.at < o.p.UnknownPing {
			continue
		}
		u.pinged = true
		o.pending[coid] = u
		o.r.anom.raise(risk.Anomaly{
			Class: "ORDER_UNKNOWN", Sev: risk.SEV2, Ticker: o.r.cfg.Ticker,
			Text: fmt.Sprintf("coid %s has been unresolved for %v (past "+
				"unknown_ping_s %v): %s contracts may be live on %s and are "+
				"still held against every aggregate cap. Only a complete orders "+
				"walk listing the coid resolves it -- absence is not evidence "+
				"in either direction (H-ORD-2a)", coid,
				(now - u.at).Truncate(time.Second), o.p.UnknownPing,
				u.qty.Wire(), u.side),
		})
	}
}

// canaryStop is pilot-plan §7.9's bound on the S=1 rung: the first directional
// entry after adoption latches WINDING_DOWN, at any size.
//
// The rung DECISION lives here and the classification lives in `harness/risk`,
// which is the split those packages already state. `risk.Portfolio` promises
// purity and leaves "the decision to act on any effect" to its caller; it
// already performs the trade-id deduplication and the ownership classification
// this rule consumes, and `wsx.PortfolioEffects` carries owned fills and
// position records with no policy attached. A rung is a fact about this
// deployment, and the owner is where deployment facts are known.
//
// Every caller must offer any STRONGER cause for the same event first.
// `commitStop` is first-writer-wins and the §10.4 operator reads the latch to
// learn WHY the harness stopped: a taker fill on the canary is truthfully
// described by both causes, and only one of them is worth being woken for.
//
// Today that means the stops `applyRead` already funnels through
// `requestStop("portfolio_read", "")` -- taker, foreign, an unavailable
// ownership ledger, an unconvertible fill, and hard position drift -- which is
// why the canary block sits below it. F17 joined them in `lip-lqw` and is
// offered from its own call, `requestStop("inv_kill", ticker)`, immediately
// above the canary block: a §12 halt-table row outranks a rung policy, and
// unlike the five above it carries a cause of its own rather than the generic
// label, because the operator of §10.4 reads the latch to learn which row of
// the table fired.
func (o *owner) canaryStop(trigger, market string) {
	if !o.r.cfg.Rung.stopOnFirstOwnedFill {
		return
	}
	o.requestStop(trigger, market)
}

// liveOwnedFill answers whether an owned fill is one this incarnation CAUSED
// rather than one it INHERITED, on identity and phase and never on a clock.
//
// A trade id absent from the startup baseline is live even if the exchange
// stamps it old, and that direction is deliberate. `rest.Fills` filters
// client-side after a complete walk, `parseTsMillis` returns 0 for a stamp it
// cannot read and a 0 bypasses the filter, and the live poll asks for all
// history while §7.5 asked for `backfill_h`. So a timestamp cannot separate a
// delayed report of our own fill from a record of last week's, and the
// conservative reading of a fill we cannot place is that we just took it.
//
// The size test is `Count > 0` and not a threshold. That is the whole point of
// the rule: fills are fractional to the 0.01-contract quantum, and any positive
// quantity is a directional entry the canary exists to stop after.
func (o *owner) liveOwnedFill(f risk.FillEvent) bool {
	if f.Count <= 0 {
		return false
	}
	_, history := o.startupTrades[f.TradeID]
	return !history
}

// requestStop asks the coordinator for a durable global stop. It is the entry
// point every §12 trigger in this file uses, and it never drops a cause.
func (o *owner) requestStop(trigger, market string) {
	o.commitStop(lifecycle.StopCause{
		Trigger: trigger, Market: market, TsMillis: o.r.ex.NowMs(),
	})
}

// commitStop is the ONE place a §12 cause is written to the durable latch, and
// so it is the one place "what happens when the write fails" is implemented.
// Both the event-driven triggers and the per-tick retry come through here.
//
// It goes through `CommitStop` and then `Advance`, in that order and never the
// other way round: H-HALT-4 requires the latch reach disk BEFORE the in-memory
// state changes, and the two calls were split precisely so that neither can be
// induced to do the other's job by a malformed argument.
func (o *owner) commitStop(cause lifecycle.StopCause) {
	if o.stopHeld {
		// A second, different trigger arriving while the first is still not on
		// disk. The HELD cause is the one written; this one is discarded, and
		// discarded silently, because the conditions that reach here are
		// standing ones -- the gate's stop is sticky and re-requests on every
		// tick -- and one anomaly per 250 ms is how the SEV1 that matters gets
		// filtered out.
		cause = o.stopCause
	}

	commit := o.r.ctrl.CommitStop(cause)
	if !commit.Durable || commit.BlockAdding || commit.RetryLatch {
		// I1's answers, HONOURED rather than observed. The disjunction is the
		// conservative reading: any one of the three means this stop is not on
		// disk, and nothing publishable comes of it.
		//
		// The stop is NOT published -- publishing a halt we failed to record is
		// the HR-009 sequence with the harness having been TOLD the write
		// failed. `BlockAdding` takes effect in `evaluate`, which is the one
		// place §5.2 stops adding, and stops nothing else: the adding side is
		// cancelled and confirmed absent, the capped reducer keeps resting, and
		// the poller, the reconciliation and the monitor never paused.
		// `RetryLatch` is why the cause is kept rather than returned from.
		if !o.stopPinged {
			o.stopPinged = true
			o.r.anom.raiseAll(commit.Anomalies)
		}
		o.holdStop(cause)
		return
	}
	o.r.anom.raiseAll(commit.Anomalies)
	o.releaseStop()

	// `Stop` is the ONLY thing this differs from an ordinary tick by, and it is
	// what makes the A9 row say `global_stop` instead of `halt_latch`: it is the
	// input `NextGlobal` reads to tell a cause committed by THIS process from a
	// latch inherited from a previous one.
	in := o.globalFacts()
	in.Stop = true
	o.advance(in)
}

// globalFacts is what this owner can attest about §5.1's inputs, in one place so
// that the stop path and the ordinary tick cannot disagree about them.
//
// Every field was a hardcoded literal at the stop call site before lip-xdq --
// including `State`, which was left at the zero value and therefore said
// STARTING on every §12 trigger. That was survivable only because A14 fired
// first and forced WINDING_DOWN regardless; it meant the machine was being
// handed a state the process had not been in for hours, and any rule that came
// to depend on it would have been reading garbage. `RiskKnown` and
// `TruthReadable` were literal `true` for the same reason and with a sharper
// edge: they gate the drain, and asserting them is `M-L-FALSEFLAT` -- "absence
// of evidence drains".
func (o *owner) globalFacts() quote.GlobalInput {
	known := o.truthKnown()
	return quote.GlobalInput{
		State:         o.global,
		TruthReadable: known,
		Reconciled:    known,
		RiskKnown:     known,
		AnyInventory:  o.anyInventory(),
		AnyLiveOrder:  o.anyLiveOrder(),
	}
}

// holdStop retains a cause whose durable write did not succeed, so that retrying
// it is this loop's OBLIGATION rather than a property of whether the condition
// that produced it happens to recur.
//
// It is also reached from two places that never call `CommitStop` themselves:
// `newOwner`, for the bootstrap's own unreadable latch, and `applySignal`, where
// `SignalController.Handle` did the commit and a signal that arrived once has no
// condition left to recur at all.
func (o *owner) holdStop(cause lifecycle.StopCause) {
	if o.stopHeld {
		return
	}
	o.stopCause, o.stopHeld = cause, true
}

// holdSignal retains an operator signal whose stop is not durable yet, so the
// exit authority it carries can be granted once something is. See `signalCause`.
func (o *owner) holdSignal(cause lifecycle.StopCause) {
	if o.signalHeld {
		return
	}
	o.signalCause, o.signalHeld = cause, true
}

// releaseStop ends the hold, and tells the operator it ended.
//
// The SEV1 that opened it said the harness had decided to stop and could not
// record it. Someone who was told that needs telling that the record now exists,
// because the two facts have opposite operational meanings and only the second
// one licenses the state that is about to be published.
func (o *owner) releaseStop() {
	if !o.stopHeld {
		return
	}
	o.r.anom.raise(risk.Anomaly{
		Class: "LATCH_WRITE_RECOVERED", Sev: risk.SEV2,
		Ticker: o.stopCause.Market,
		Text: fmt.Sprintf("a durable halt latch is now CONFIRMED after %d "+
			"retried tick(s), so the global state it justifies may be "+
			"published. The cause this process held was %q; the latch is "+
			"first-writer-wins and `Ensure` guarantees only that a record -- "+
			"this one OR AN EARLIER INCARNATION'S -- is on disk, so read the "+
			"file for the authoritative reason rather than assuming it is this "+
			"trigger. Adding was blocked for the whole gap and cancelling, "+
			"reducing, polling, reconciling and monitoring never stopped (I1)",
			o.stopRetries, o.stopCause.Trigger),
	})
	o.stopCause, o.stopHeld = lifecycle.StopCause{}, false
	o.stopPinged, o.stopRetries = false, 0
	o.confirmSignalDrain()
}

// confirmSignalDrain grants the exit authority a signal earned but could not be
// given, now that a durable stop exists.
//
// It runs on the RELEASE and not on the signal, because the permit attests
// durability and there was none to attest when the signal arrived. `BeginPlanned`
// upgrades the unplanned drain `onSignal` already started rather than restarting
// its escalation clock, which is what `DrainTracker.start` documents for an
// operator who signals a harness already winding down from another cause.
func (o *owner) confirmSignalDrain() {
	if !o.signalHeld {
		return
	}
	cause := o.signalCause
	o.signalCause, o.signalHeld = lifecycle.StopCause{}, false
	o.sd.confirmSignalDrain(cause)
}

// retryStop is `RetryLatch`, honoured: the held cause is written again on every
// owner tick until it is durable.
//
// It is driven from `evaluate`, which runs on EVERY iteration of the run loop --
// the 250 ms tick and every event alike -- and that is the whole point. A failed
// latch write is a transient disk condition far more often than a permanent one,
// and the cost of retrying is nothing.
func (o *owner) retryStop() {
	if !o.stopHeld {
		return
	}
	o.stopRetries++
	o.commitStop(o.stopCause)
}

// advance is the one FUNCTION in this process that moves the global state, and
// that is H-HALT-2's property rather than a per-tick budget: "there is exactly
// one place in the codebase that transitions the global state... Both write a
// `state_event` row with the trigger. A grep for those two functions enumerates
// every stop path in the system."
//
// It is called more than once on some ticks, and that is worth writing down
// rather than glossing: the stop funnel calls it on the tick a §12 cause becomes
// durable, and `evaluate` calls it on every tick for §5.1's other edges. The
// second call is a no-op by construction -- `NextGlobal` returns `GTNone`
// beside an unchanged state and `mirrorGlobal` refuses to record one -- so
// nothing is published twice.
//
// The comment this replaces claimed it was "the ONE call per tick that can move
// the global state (§3.8)". That was already untrue when it was written --
// `requestStop` has three event-driven callers -- and §3.8 is a section
// `harness-spec.md` does not contain. See lip-4nb for the two other files
// carrying the same dangling citation.
func (o *owner) advance(in quote.GlobalInput) {
	dec := o.r.ctrl.Advance(in)
	o.r.anom.raiseAll(dec.Anomalies)
	if !dec.Committed {
		return
	}
	o.sd.mirrorGlobal(o.global, dec)
	o.global = dec.State
}

func (o *owner) anyInventory() bool {
	for _, q := range o.r.pf.Positions() {
		if q != 0 {
			return true
		}
	}
	return false
}

// anyLiveOrder is H-FAIL-3's definition, and the three terms are not
// interchangeable: RESTING is the confirmed walk, SENDING is the write in
// flight, and UNKNOWN is a create whose outcome was never resolved. DRAINED
// requires all three to be empty, because "an account that is flat but still has
// fillable orders on the book is not drained: it is one ignored cancel away from
// being long again."
func (o *owner) anyLiveOrder() bool {
	return len(o.r.pf.LiveOrders()) > 0 || len(o.inflight) > 0 || len(o.retries) > 0 ||
		len(o.pending) > 0
}

// truthKnown is whether all three portfolio reads are inside `truth_max_age_s`.
//
// A drain authorised from stale truth is a drain authorised from the last
// reading before the outage, and H-FAIL-4 exists because that reading looks
// exactly like a good one.
func (o *owner) truthKnown() bool {
	if o.awaitCancelTruth {
		return false
	}
	now := o.r.ex.Clock.Now()
	for _, k := range []wsx.Truth{wsx.TruthOrders, wsx.TruthFills, wsx.TruthPositions} {
		age := o.r.gate.TruthAge(k, now)
		if age < 0 || age > o.p.TruthMaxAge {
			return false
		}
	}
	return true
}

// publish is H-TOP-5: the owner stamps a fresh Seq on every tick, and the
// monitor's whole stall detector is built on that number advancing.
//
// It publishes UNCONDITIONALLY, at the end of every tick, including ticks that
// decided nothing and ticks taken in a halted state. That is the point: I2 makes
// the monitor unstoppable but does not make it truthful, and an owner that
// stopped publishing while continuing to run would leave the monitor
// re-reporting a snapshot that was true once. A5 would pass at every tick while
// real inventory grew unobserved.
func (o *owner) publish(now time.Duration) {
	o.snapSeq++
	ticker := o.r.cfg.Ticker
	book := o.r.book.Book(ticker)

	snap := &risk.Snapshot{
		Seq:       o.snapSeq,
		PubMono:   now,
		PubWallMs: o.r.ex.NowMs(),
		Global:    o.global,
	}

	m := risk.MarketSnap{
		Ticker:         ticker,
		State:          o.market,
		Q:              o.r.pf.Q(ticker),
		Selected:       true,
		BookActionable: o.r.gate.Actionable(ticker, o.r.ex.Clock.Now()),
	}
	if book != nil {
		// Gated: the market's own qualifying walk fails on either side. Reward
		// for a gated interval is zero for every participant, so it is excluded
		// from the uptime denominator rather than counted as our downtime
		// (H-Q-4).
		m.Gated = book.Qualifies() == 0
		for _, side := range []quote.Side{quote.SideYes, quote.SideNo} {
			levels := book.Yes()
			if side == quote.SideNo {
				levels = book.No()
			}
			ours, price, has := o.restingOn(side)
			ext := quote.ExternalBest(levels, ours)
			s := risk.SideSnap{AtRisk: o.atRisk(side)}
			if has {
				s.PriceCents = price
			}
			for _, r := range ours {
				if r.Price == price {
					s.Resting = r.Size
				}
			}
			if ext.Found {
				s.TouchCents = ext.Price
				s.FieldScore = ext.Size
			}
			m.Sides[side] = s
		}
	}
	snap.Markets = []risk.MarketSnap{m}
	o.r.snap.Store(snap)
	if o.r.qual != nil {
		name := fmt.Sprintf("global=%s;market=%s;actionable=%t;truth_generation=%d",
			o.global, o.market, m.BookActionable, o.r.gate.Generation())
		if err := o.r.qual.RecordEvent("state", name, time.Now().UTC()); err != nil {
			o.r.failQualification(fmt.Errorf("recording state summary: %w", err))
		}
	}
}

// confidence: high
