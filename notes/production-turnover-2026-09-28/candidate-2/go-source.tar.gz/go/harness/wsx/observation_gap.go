package wsx

// ObservationGap retires every pre-gap book/read without pretending the socket
// reconnected. Host sleep can leave it open, with old REST requests in flight.
// Only newly started reads carrying the returned token may restore authority.
func (g *Gate) ObservationGap(now Stamp) ReconcileToken {
	g.gen++
	g.NoteSeqGap(now)
	for _, m := range g.markets {
		m.clearQuietEpisode()
		m.f5 = false
		m.restOK = false
		m.lastFrame = now.Mono
		m.quietPinged = false
	}
	return ReconcileToken{gen: g.gen, valid: true}
}

// confidence: high
