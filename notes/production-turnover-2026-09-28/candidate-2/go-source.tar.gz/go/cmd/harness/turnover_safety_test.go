package main

import (
	"sync/atomic"
	"testing"
	"time"

	"lip/harness/num"
	"lip/harness/quote"
	"lip/harness/rest"
	"lip/harness/risk"
	"lip/harness/wsx"
)

func turnoverOwnerForSafety(t *testing.T, q num.Qty) *gateFailOwner {
	t.Helper()
	g := capitalOwner(t, 0, 120)
	if q != 0 {
		g.h.installPosition(q)
	}
	o := g.o
	o.r.cfg.Turnover = true
	o.r.cfg.CapitalSource = "selected_shard_balance"
	o.r.cfg.Funding = &fundingEvidence{Ticker: seamTicker, ExchangeIndex: 2}
	o.r.cfg.Candidates = []string{seamTicker, turnoverOtherTicker}
	o.r.cfg.ShardFunding = map[string]fundingEvidence{
		seamTicker:          {Ticker: seamTicker, ExchangeIndex: 2, Effective: num.MoneyFromDollars(20)},
		turnoverOtherTicker: {Ticker: turnoverOtherTicker, ExchangeIndex: 3, Effective: num.MoneyFromDollars(100)},
	}
	o.r.funding = new(atomic.Pointer[fundingObservation])
	o.r.funding.Store(&fundingObservation{valid: true, at: g.o.r.ex.Mono(), byTicker: map[string]int{seamTicker: 2, turnoverOtherTicker: 3}, byShard: map[int]num.Money{2: num.MoneyFromDollars(2), 3: num.MoneyFromDollars(100)}})
	o.markets = map[string]*marketRuntime{seamTicker: {}, turnoverOtherTicker: {market: quote.Idle, programMembership: programMembership{ticker: turnoverOtherTicker}}}
	o.saveMarket()
	o.targets = map[string]float64{seamTicker: seamTarget, turnoverOtherTicker: seamTarget}
	return g
}
func TestTurnoverReducerSizesFromItsOwnShardCash(t *testing.T) {
	g := turnoverOwnerForSafety(t, num.QtyFromFloat(10))
	got := g.o.fundedReducer(num.QtyFromFloat(10))
	want := risk.FundedContracts(num.MoneyFromDollars(2), num.Price4FromCents(seamNoTouch))
	if got != want || got <= 0 || got >= num.QtyFromFloat(10) {
		t.Fatalf("shard-constrained partial reducer=%s want=%s", got.Wire(), want.Wire())
	}
	// An existing compliant partial exit must not be cancelled merely because
	// the cash it occupies is conservatively reserved from the observed balance.
	g.o.pending["held-partial"] = pendingOrder{ticker: seamTicker, side: quote.SideNo, cents: seamNoTouch, qty: got, acked: true, id: "held"}
	if funded := g.o.fundedReducer(num.QtyFromFloat(10)); funded < got {
		t.Fatalf("funding shrank an already compliant exit: %s < %s", funded.Wire(), got.Wire())
	}
}
func TestTurnoverPendingOrderIdentityDoesNotLeakAcrossMarkets(t *testing.T) {
	g := turnoverOwnerForSafety(t, 0)
	g.o.pending["old-unknown"] = pendingOrder{ticker: seamTicker, side: quote.SideYes, cents: 40, qty: num.QtyFromFloat(3), id: "old-owned", acked: true}
	restore := g.o.marketContext(turnoverOtherTicker)
	if got := g.o.atRisk(quote.SideYes); got != 0 {
		t.Fatalf("A pending contaminated B side quantity: %s", got.Wire())
	}
	if orders := g.o.unlistedOn(turnoverOtherTicker, quote.SideYes); len(orders) != 0 {
		t.Fatalf("A order entered B cancel list: %+v", orders)
	}
	restore()
	if got := g.o.atRisk(quote.SideYes); got != num.QtyFromFloat(3) {
		t.Fatalf("old obligation lost: %s", got.Wire())
	}
}
func TestTurnoverResnapshotIncludesOldManagedMarket(t *testing.T) {
	g := turnoverOwnerForSafety(t, 0)
	out := make(chan wsx.Command, 4)
	g.o.wsCommands = out
	g.o.bookSID = 1
	g.o.resnapshot(true)
	seen := map[string]bool{}
	for len(out) > 0 {
		cmd := <-out
		for _, ticker := range cmd.Tickers {
			seen[ticker] = true
		}
	}
	if !seen[seamTicker] || !seen[turnoverOtherTicker] {
		t.Fatalf("resnapshot did not include all managed books: %v", seen)
	}
}
func TestTurnoverCrossCheckBackpressureRetainsRequests(t *testing.T) {
	g := turnoverOwnerForSafety(t, 0)
	out := make(chan wsx.CrossCheckRequest, 1)
	g.o.crossChecks = out
	rows := []wsx.CrossCheckRequest{{Ticker: "A"}, {Ticker: "B"}, {Ticker: "C"}}
	g.o.requestCrossChecks(rows)
	if len(g.o.crossCheckPending) != 2 {
		t.Fatalf("queued request was treated as failed evidence: %d", len(g.o.crossCheckPending))
	}
	if got := (<-out).Ticker; got != "A" {
		t.Fatal(got)
	}
	g.o.flushCrossChecks()
	if got := (<-out).Ticker; got != "B" {
		t.Fatal(got)
	}
	g.o.flushCrossChecks()
	if got := (<-out).Ticker; got != "C" {
		t.Fatal(got)
	}
}
func TestTurnoverCompleteOmissionRetainsOwnedObligation(t *testing.T) {
	g := turnoverOwnerForSafety(t, 0)
	g.o.pending["unknown-A"] = pendingOrder{ticker: seamTicker, side: quote.SideYes, cents: 40, qty: num.QtyFromFloat(1), at: g.o.r.ex.Mono(), id: "known-id", acked: true}
	g.o.clearListed()
	g.o.applyTurnoverTerminals(turnoverTerminalRead{orders: rest.OrdersResult{Walk: rest.Walk{Outcome: rest.WalkComplete}}, started: g.o.r.ex.Mono()})
	if g.o.pending["unknown-A"].qty != num.QtyFromFloat(1) || !g.o.anyLiveOrder() {
		t.Fatal("omission released possibly-live owned exposure")
	}
}
func TestTurnoverSelectionExpiresWithoutFreshEvidence(t *testing.T) {
	g := turnoverOwnerForSafety(t, 0)
	g.o.selected = map[string]bool{seamTicker: true}
	g.o.turnoverReady = true
	g.o.turnoverAccountingReady = true
	g.o.selectionAt = g.o.r.ex.Mono()
	if !g.o.isSelected(seamTicker) {
		t.Fatal("fresh selected market unavailable")
	}
	g.h.clk.Advance(g.o.p.TruthMaxAge + time.Millisecond)
	if g.o.isSelected(seamTicker) {
		t.Fatal("stale selection retained adding authority")
	}
}

func TestTurnoverPositiveTerminalWaitsForInflightResult(t *testing.T) {
	g := turnoverOwnerForSafety(t, 0)
	g.h.installOwnedOrder("terminal-owned", 911)
	coid, _ := g.o.r.store.Ownership().Bound("terminal-owned")
	order, err := rest.NewCreateOrder(seamTicker, quote.SideYes, 40, num.QtyFromFloat(1), num.QtyFromFloat(1), coid)
	if err != nil {
		t.Fatal(err)
	}
	g.o.pending[coid] = pendingOrder{ticker: seamTicker, side: quote.SideYes, cents: 40, qty: num.QtyFromFloat(1), at: g.o.r.ex.Mono(), acked: true, id: "terminal-owned"}
	g.o.inflight = []*writeRequest{{Market: seamTicker, Side: quote.SideYes, Op: quote.OpPlace, Order: order}}
	read := turnoverTerminalRead{started: g.o.r.ex.Mono(), orders: rest.OrdersResult{Walk: rest.Walk{Outcome: rest.WalkComplete}, Orders: []rest.Order{{OrderID: "terminal-owned", ClientOrderID: coid, Ticker: seamTicker, Side: quote.SideYes, Price4: 4000, Status: rest.StatusExecuted}}}}
	g.o.applyTurnoverTerminals(read)
	if _, ok := g.o.pending[coid]; !ok {
		t.Fatal("terminal retired while delayed create result could resurrect it")
	}
	g.o.inflight = nil
	g.o.applyTurnoverTerminals(read)
	if _, ok := g.o.pending[coid]; ok {
		t.Fatal("positive bound terminal did not retire obligation")
	}
}

func TestTurnoverUnboundPositiveTerminalBindsBeforeRetirement(t *testing.T) {
	g := turnoverOwnerForSafety(t, 0)
	req := capitalOrder(t, g, quote.SideYes, quote.RoleAdding, 40, 1, 912)
	coid := req.Order.ClientOrderID()
	if _, err := g.o.r.store.ReserveOrder(g.o.r.run, req.Order, req.Role, g.o.r.ex.NowMs()); err != nil {
		t.Fatal(err)
	}
	g.h.await("unbound reservation committed", func() bool { _, ok := g.o.r.store.Ownership().Unresolved()[coid]; return ok })
	g.o.pending[coid] = pendingOrder{ticker: seamTicker, side: quote.SideYes, cents: 40, qty: num.QtyFromFloat(1), at: g.o.r.ex.Mono()}
	read := turnoverTerminalRead{started: g.o.r.ex.Mono(), orders: rest.OrdersResult{Walk: rest.Walk{Outcome: rest.WalkComplete}, Orders: []rest.Order{{OrderID: "immediate-fill", ClientOrderID: coid, Ticker: seamTicker, Side: quote.SideYes, Price4: 4000, Status: rest.StatusExecuted}}}}
	g.o.applyTurnoverTerminals(read)
	if _, ok := g.o.pending[coid]; !ok {
		t.Fatal("released before binding committed")
	}
	g.h.await("terminal binding committed", func() bool { got, ok := g.o.r.store.Ownership().Bound("immediate-fill"); return ok && got == coid })
	g.o.applyTurnoverTerminals(read)
	if _, ok := g.o.pending[coid]; ok {
		t.Fatal("unbound terminal never retired after durable binding")
	}
}

func TestTurnoverForeignPrefixIsNotOwnedSweepEvidence(t *testing.T) {
	g := turnoverOwnerForSafety(t, 0)
	foreign := rest.Order{OrderID: "foreign", ClientOrderID: "lip-foreign-shaped", Ticker: seamTicker, Side: quote.SideYes, Price4: 4000, Remaining: num.QtyFromFloat(1)}
	if g.o.acceptTurnoverOwnedSighting(foreign) {
		t.Fatal("prefix-shaped foreign order admitted as owned")
	}
}

func TestTurnoverMonitorPreservesAggregateAndInvalidatesStalledPnL(t *testing.T) {
	snapshot := &risk.Snapshot{Seq: 1, Account: risk.AccountSnapshot{TruthFresh: true, CapitalMax: num.MoneyFromDollars(2), Exposures: []risk.Exposure{{Ticker: "A", Position: num.MoneyFromDollars(1)}, {Ticker: "B", Adding: num.MoneyFromDollars(.5)}}, TradingPnL: risk.PnLResult{Evaluable: true, Total: num.MoneyFromDollars(.1)}}}
	var monitor risk.MonitorState
	fresh := monitor.Step(0, snapshot, time.Second)
	if !fresh.Account.TruthFresh || !fresh.Account.TradingPnL.Evaluable || risk.Deployed(fresh.Account.Exposures) != num.MoneyFromDollars(1.5) {
		t.Fatalf("aggregate publication lost: %+v", fresh.Account)
	}
	stale := monitor.Step(2*time.Second, snapshot, time.Second)
	if !stale.Stale || stale.Account.TruthFresh || stale.Account.TradingPnL.Evaluable {
		t.Fatalf("stalled aggregate claimed current truth: %+v", stale)
	}
	if !snapshot.Account.TruthFresh || !snapshot.Account.TradingPnL.Evaluable {
		t.Fatal("monitor mutated owner publication")
	}
}

// confidence: high
