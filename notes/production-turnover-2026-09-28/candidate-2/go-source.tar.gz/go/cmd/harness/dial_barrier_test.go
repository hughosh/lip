package main

import (
	"context"
	"errors"
	"net"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

type closeDialResolver struct {
	failed atomic.Bool
	calls  atomic.Int32
}

func (r *closeDialResolver) LookupHost(context.Context, string) ([]string, error) {
	r.calls.Add(1)
	if r.failed.Load() {
		return nil, errors.New("injected resolver failure")
	}
	return []string{"192.0.2.10"}, nil
}

func TestServingCloseWaitsForDetachedDialReport(t *testing.T) {
	h := newSeamHarness(t, seamOptions{ReadOnly: true})
	resolver := &closeDialResolver{}
	var advanced atomic.Bool
	var block atomic.Bool
	entered, release := make(chan struct{}), make(chan struct{})
	var releaseOnce sync.Once
	defer releaseOnce.Do(func() { close(release) })
	nt, err := newF6Net(h.rig.anom, resolver, func(context.Context, string, string) (net.Conn, error) {
		if block.Load() {
			close(entered)
			<-release
		}
		client, server := net.Pipe()
		_ = server.Close()
		return client, nil
	}, func() time.Time {
		at := time.Unix(1_700_000_000, 0)
		if advanced.Load() {
			return at.Add(2 * time.Hour)
		}
		return at
	})
	if err != nil {
		t.Fatal(err)
	}
	// Populate the actual shared resolver cache. The next, expired lookup fails
	// and reports through the production fallback reporter only after dial ends.
	conn, err := nt.rest.DialContext(context.Background(), "tcp", "example.test:443")
	if err != nil {
		t.Fatal(err)
	}
	_ = conn.Close()
	advanced.Store(true)
	resolver.failed.Store(true)
	block.Store(true)
	quiesceReturned := make(chan struct{})
	h.rig.ex.quiesce = func(ctx context.Context) error {
		err := nt.dials.pause(ctx)
		close(quiesceReturned)
		return err
	}
	h.rig.ex.resume = nt.dials.resume
	sd := startServingClose(t, h, &servingCloseStepper{})
	h.awaitActionable()
	dialDone := make(chan error, 1)
	go func() {
		conn, err := nt.rest.DialContext(context.Background(), "tcp", "example.test:443")
		if conn != nil {
			_ = conn.Close()
		}
		dialDone <- err
	}()
	<-entered
	stopDone := make(chan error, 1)
	go func() { stopDone <- sd.stop(context.Background()) }()
	h.await("transport final-close fence", func() bool { nt.dials.mu.Lock(); defer nt.dials.mu.Unlock(); return nt.dials.paused })
	select {
	case err := <-stopDone:
		t.Fatalf("close overtook detached fallback: %v", err)
	default:
	}
	// A Transport goroutine scheduled after the fence may not reach the dialer.
	calls := resolver.calls.Load()
	if conn, err := nt.ws.DialContext(context.Background(), "tcp", "late.test:443"); err == nil {
		_ = conn.Close()
		t.Fatal("late scheduled dial crossed final-close fence")
	}
	if resolver.calls.Load() != calls {
		t.Fatal("late dial invoked resolver after pause")
	}
	// Keep the accepted callback outstanding long enough to observe the
	// barrier itself. An immediate stopDone poll only tests scheduler order;
	// final alert/store work can conceal a missing transport join.
	select {
	case <-quiesceReturned:
		t.Fatal("transport quiesce returned with a detached reporter outstanding")
	case <-time.After(100 * time.Millisecond):
	}
	releaseOnce.Do(func() { close(release) })
	if err := <-dialDone; err != nil {
		t.Fatal(err)
	}
	if err := <-stopDone; err != nil {
		t.Fatal(err)
	}
	if got := servingCloseAnomalyCount(t, h.cfg.Paths.DB, "DNS_FALLBACK"); got != 1 {
		t.Fatalf("detached fallback durable rows=%d, want 1", got)
	}
}

func TestDialFenceRefusalResumesWithoutOverlappingActiveDial(t *testing.T) {
	var b dialBarrier
	if !b.enter() {
		t.Fatal("initial registration refused")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := b.pause(ctx); err == nil {
		t.Fatal("pause claimed outstanding dial joined")
	}
	if b.enter() {
		t.Fatal("pause allowed another dial")
	}
	b.resume()
	if !b.enter() {
		t.Fatal("refused pause did not restore admission")
	}
	b.leave()
	b.leave()
	if err := b.pause(context.Background()); err != nil {
		t.Fatal(err)
	}
}
